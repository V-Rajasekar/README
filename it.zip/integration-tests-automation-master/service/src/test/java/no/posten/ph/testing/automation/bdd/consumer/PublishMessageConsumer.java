package no.posten.ph.testing.automation.bdd.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import no.posten.ph.oem.edi.consignment.consumer.model.ConsignmentPublishObject;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

@Component
@Profile("bdd")
public class PublishMessageConsumer {
    static final Logger LOG = LoggerFactory.getLogger(PublishMessageConsumer.class);
    private CountDownLatch latch = new CountDownLatch(1);
    private String payload = null;
    private String originalPayload = null;
    private Headers headers = null;
    private Headers originalHeaders = null;
    private ConsignmentPublishObject consignmentPublishObject;
    private ConsignmentPublishObject originalConsignmentPublishObject;
    private String consignmentNo;
    private String consignmentItemNo;
    private String originalConsignmentNo;

    @Autowired
    ObjectMapper objectMapper;

    @KafkaListener(topics = "${spring.kafka.consumer.publishtopic}", groupId = ("${spring.kafka.consumer.group-id}"))
    public void onMessage(ConsumerRecord<String, String> consumerRecord) {
        try {
            if ((consumerRecord!=null) && (consumerRecord.value()!=null)) {
                ConsignmentPublishObject consignmentPublishObject = objectMapper.readValue(consumerRecord.value(), ConsignmentPublishObject.class);
                LOG.info("Response message - Consignment number: " + consignmentPublishObject.getConsignmentNo());
                if ((this.consignmentNo != null) && (this.consignmentNo.equals(consignmentPublishObject.getConsignmentNo())) || (this.consignmentItemNo != null && consignmentPublishObject
                        .getConsignmentItems()
                        .stream()
                        .anyMatch(consItem -> consItem.getConsignmentItemNo().equals(this.consignmentItemNo)))) {
                    this.headers = consumerRecord.headers();
                    this.payload = consumerRecord.value();
                    this.consignmentPublishObject = consignmentPublishObject;
                    if (this.latch != null) {
                        this.latch.countDown();
                    }
                }
                if ((this.originalConsignmentNo!=null) && (this.originalConsignmentNo.equals(consignmentPublishObject.getConsignmentNo()))) {
                    this.originalHeaders = consumerRecord.headers();
                    this.originalPayload = consumerRecord.value();
                    this.originalConsignmentPublishObject = consignmentPublishObject;
                    if (this.latch!=null) this.latch.countDown();
                }

            }
        } catch (JsonProcessingException e) {
            LOG.error("Error parsing the output message: ", e);
        }

    }

    public void setContext(String consignmentNo, String consignmentItemNo, String originalConsignmentNo,
                           CountDownLatch countDownLatch){
        this.consignmentNo = consignmentNo;
        this.consignmentItemNo = consignmentItemNo;
        this.originalConsignmentNo = originalConsignmentNo;
        this.latch = countDownLatch;
    }

    public void clearContext(){
        LOG.debug("Clearing context for the Publish consumer");
        this.consignmentNo = null;
        this.originalConsignmentNo = null;
        this.headers =null;
        this.payload =null;
        this.consignmentPublishObject = null;
        this.originalHeaders = null;
        this.originalPayload = null;
        this.originalConsignmentPublishObject = null;
        this.latch = null;
    }


    public Headers getHeaders() {
        return headers;
    }

    public ConsignmentPublishObject getConsignmentPublishObject() {
        try {
            LOG.debug("Document on published topic = " + objectMapper.writeValueAsString(consignmentPublishObject));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return consignmentPublishObject;
    }

    public Headers getOriginalHeaders() {
        return originalHeaders;
    }

    public ConsignmentPublishObject getOriginalConsignmentPublishObject() {
        return originalConsignmentPublishObject;
    }

    public List<String> getErrorCodes(){
        List<String> errorCodes = new ArrayList<>();
        if ( (this.getConsignmentPublishObject()!=null) && (this.getConsignmentPublishObject().getValidationErrors()!=null))
            this.getConsignmentPublishObject().getValidationErrors().stream().forEach(e->errorCodes.add(e.getType()+e.getCode()));
        LOG.debug("Published message has warning codes " + errorCodes);
        return errorCodes;
    }
}

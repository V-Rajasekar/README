package no.posten.ph.testing.automation.bdd.repository;

import com.azure.cosmos.models.PartitionKey;
import no.posten.ph.oem.consignment.domain.constant.ApplicationConstants;
import no.posten.ph.oem.consignmentitem.api.domain.item.ConsignmentItemCosmos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CosmosItemRepositoryService {

    private static final Logger LOG = LoggerFactory.getLogger(CosmosItemRepositoryService.class);

    private ConsignmentItemRepository consignmentItemRepository;

    public static final String DOC_TYPE_CONSIGNMENT_ITEM = "ConsItem";

    @Autowired
    public CosmosItemRepositoryService(ConsignmentItemRepository consignmentItemRepository) {
        this.consignmentItemRepository = consignmentItemRepository;
    }

    /**
     * Get ConsignmentItem document using ID(consNo + DocType) from cosmos DB
     *
     * @param consignmentItemNo
     * @return
     */
    public ConsignmentItemCosmos findConsignmentItemById(String consignmentItemNo) {
        return consignmentItemRepository.findById(generateId(consignmentItemNo, DOC_TYPE_CONSIGNMENT_ITEM),
                new PartitionKey(consignmentItemNo)).orElse(null);
    }

    public void saveConsignmentItem(ConsignmentItemCosmos consignmentItemCosmos) {
        if (consignmentItemCosmos != null) {
            LOG.debug("Saving the {} details for consignmentItemCosmos # {}", DOC_TYPE_CONSIGNMENT_ITEM, consignmentItemCosmos.getConsItemNo());
            consignmentItemCosmos.setId(generateId(consignmentItemCosmos.getConsItemNo(), DOC_TYPE_CONSIGNMENT_ITEM));
            consignmentItemRepository.save(consignmentItemCosmos);
        }
    }

    /**
     * To generate Document id
     *
     * @param consignmentNo
     * @param documentType
     * @return
     */
    private String generateId(String consignmentNo, String documentType) {
        if (consignmentNo == null) {
            throw new IllegalArgumentException("Id cannot be generated");
        }
        return consignmentNo + ApplicationConstants.COLON + documentType;
    }
}

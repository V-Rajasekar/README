package no.posten.ph.testing.automation.bdd.stepdefs;


import static no.posten.ph.testing.automation.bdd.domain.Document.BASELINENUMBER;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.spring.CucumberContextConfiguration;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import no.posten.ph.oem.cbm.adapter.consumer.schemas.jaxb.X0420PShipmentEventInfoImport;
import no.posten.ph.oem.consignment.domain.service.CosmosRepositoryService;
import no.posten.ph.oem.consignmentitem.api.domain.item.ConsignmentItemCosmos;
import no.posten.ph.oem.edi.consignment.consumer.model.ConsignmentPublishObject;
import no.posten.ph.testing.automation.bdd.config.KafkaConfig;
import no.posten.ph.testing.automation.bdd.config.TestAzureCosmosDBConfiguration;
import no.posten.ph.testing.automation.bdd.consumer.ConsItemPublishMessageConsumer;
import no.posten.ph.testing.automation.bdd.consumer.ConsPublishObjectDeadLetterConsumer;
import no.posten.ph.testing.automation.bdd.consumer.DeadLetterConsumer;
import no.posten.ph.testing.automation.bdd.consumer.PublishMessageConsumer;
import no.posten.ph.testing.automation.bdd.domain.Document;
import no.posten.ph.testing.automation.bdd.repository.CosmosItemRepositoryService;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.function.Executable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ResourceLoader;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.CollectionUtils;

/**
 * This class should deal with the integration with various sources like Kafka ,Cosmos and files etc
 * again should have generic logic which should be useful before EDI testing
 */
@CucumberContextConfiguration
@Profile("bdd")
@SpringBootTest(classes = {CosmosRepositoryService.class, TestAzureCosmosDBConfiguration.class, KafkaConfig.class, DeadLetterConsumer.class,
        ConsPublishObjectDeadLetterConsumer.class, PublishMessageConsumer.class,
        ConsItemPublishMessageConsumer.class, CosmosItemRepositoryService.class})
public class SpringIntegrationTest {
    static final Logger LOG = LoggerFactory.getLogger(SpringIntegrationTest.class);

    @Autowired
    ResourceLoader resourceLoader;

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    CosmosRepositoryService cosmosRepositoryService;

    @Autowired
    CosmosItemRepositoryService cosmosItemRepositoryService;

    @Autowired
    DeadLetterConsumer deadLetterConsumer;

    @Autowired
    ConsPublishObjectDeadLetterConsumer consPublishObjectDeadLetterConsumer;

    @Autowired
    PublishMessageConsumer publishMessageConsumer;

    @Autowired
    ConsItemPublishMessageConsumer consItemPublishMessageConsumer;

    @Value("${spring.kafka.consumer.topic}")
    private String topicName;

    private static final String DEFAULT_IDENTIFIER_GENERATOR_TYPE = "Consignment";

    public static final String IDENTIFIER_GENERATOR_CONS_ITEM = "ConsItem";

    @Autowired
    ObjectMapper objectMapper;

    private static JAXBContext jaxbContext;

    static {
        try {
            jaxbContext = JAXBContext.newInstance(X0420PShipmentEventInfoImport.class);
        } catch (JAXBException jxb) {
            throw new RuntimeException(jxb);
        }
    }

    Random random = new Random();
    int randomNum = 0;
    String testCaseNo;
    String consignmentNo;
    String consItemNo;
    String consignmentNoOriginal;
    String consignmentItemNo;
    String consignmentItemNoOriginal;
    String identifierGenerationType = DEFAULT_IDENTIFIER_GENERATOR_TYPE;
    List<String> consignmentItemNos;

    List<AssertionError> assertions = new ArrayList<>();

    List<Executable> executables = new ArrayList<>();

    Map<Document.DocID, Document> documentMap = new HashMap<>();

    protected void clearContext() {
        this.consignmentNo = null;
        this.consItemNo = null;
        this.consignmentNoOriginal = null;
        this.consignmentItemNo = null;
        this.consignmentItemNoOriginal = null;
        this.testCaseNo = null;
        this.documentMap = new HashMap<>();
        this.assertions = new ArrayList<>();
        this.executables = new ArrayList<>();
        this.publishMessageConsumer.clearContext();
        this.consItemPublishMessageConsumer.clearContext();
        this.deadLetterConsumer.clearContext();
        this.consPublishObjectDeadLetterConsumer.clearContext();
    }

    public void createARandomConsignmentNo(String testCaseNo) {
        clearContext();
        int random = this.random.nextInt();
        if (random < 0) random = random * -1;
        randomNum = random;
        Document.DocID docId = new Document.DocID(Document.MBCONS, 0, null);
        Document doc = new Document(docId, DEFAULT_IDENTIFIER_GENERATOR_TYPE, null, random, testCaseNo, objectMapper, null,
                null);
        this.consignmentNo = doc.getIdentifier();
        LOG.info("Random consignment number generated :" + consignmentNo + " for testCaseNo " + testCaseNo);
        this.documentMap.put(doc.getDocId(), doc);
        assertions = new ArrayList<>();
        executables = new ArrayList<>();
    }

    public void createConsIdentifierWithARandomNo(String identifierGenerationType,
                                                  String testCaseNo) {
        clearContext();
        int random = this.random.nextInt();
        if (random < 0) random = random * -1;
        randomNum = random;
        this.testCaseNo = testCaseNo;
        this.identifierGenerationType = identifierGenerationType;
        String identifier = BigInteger.valueOf(randomNum).add(BASELINENUMBER).toString();
        if (identifierGenerationType.equalsIgnoreCase(IDENTIFIER_GENERATOR_CONS_ITEM)) {
            this.consItemNo = identifier;
            LOG.info("Assigned random consItemNo:{} for testCaseNo:{}",
                    identifier, testCaseNo);
        } else {
            this.consignmentNo = identifier;
            LOG.info("Assigned random consignmentNo:{} for testCaseNo:{}",
                    identifier, testCaseNo);
        }
        assertions = new ArrayList<>();
        executables = new ArrayList<>();
    }

    public void createARandomConsignmentNoWithDocType(String testCaseNo, String docType) throws JAXBException {
        clearContext();
        int random = this.random.nextInt();
        if (random < 0) random = random * -1;
        randomNum = random;
        Document.DocID docId = new Document.DocID(docType, 0, null);
        Document doc = new Document(docId, random, testCaseNo, jaxbContext.createMarshaller(), jaxbContext.createUnmarshaller(), null, null);
        this.consignmentNo = doc.getIdentifier();
        LOG.info("Random consignment number generated :" + consignmentNo + " for testCaseNo " + testCaseNo);
        this.documentMap.put(doc.getDocId(), doc);
        assertions = new ArrayList<>();
        executables = new ArrayList<>();
    }

    protected void await(int numOfMessages) throws InterruptedException {
        CountDownLatch countDownLatch = new CountDownLatch(numOfMessages);
        publishMessageConsumer.setContext(consignmentNo, consItemNo, consignmentNoOriginal, countDownLatch);
        consItemPublishMessageConsumer.setContext(consignmentItemNo, consignmentItemNoOriginal, countDownLatch);
        deadLetterConsumer.setContext(consignmentNo, countDownLatch, numOfMessages);
        consPublishObjectDeadLetterConsumer.setContext(consignmentNo, countDownLatch);
        countDownLatch.await(30, TimeUnit.SECONDS);
    }

    protected void await() throws InterruptedException {
        await(1);
    }

    public Document getDoc(Document.DocID docID) {
        Document doc = documentMap.get(docID);
        if (doc == null) {
            doc = createDoc(docID);
            documentMap.put(doc.getDocId(), doc);
        }
        return doc;
    }

    public Document createDoc(Document.DocID docID) {
        if (docID.path() == null) {
            return new Document(docID,
                    this.identifierGenerationType,
                    this.consignmentNo,
                    randomNum,
                    testCaseNo,
                    objectMapper,
                    getDocumentLoader(docID.docType()),
                    getDocumentPersister(docID.docType()));
        }
        return new Document(docID, this.identifierGenerationType, this.consignmentNo, randomNum, testCaseNo,
                objectMapper, null,
                null);

    }

    public Function<String, Object> getDocumentLoader(String docType) {
        if (Document.EDI.equals(docType)) return cosmosRepositoryService::findConsignmentById;
        else if (Document.OPS.equals(docType)) return cosmosRepositoryService::findOpsConsignmentById;
        else if (Document.GOODS.equals(docType)) return cosmosRepositoryService::findGoodsItemById;
        else if (Document.ITEM.equals(docType)) return cosmosItemRepositoryService::findConsignmentItemById;
        else return null;
    }

    public Consumer<String> getDocumentPersister(String docType) {
        if (Document.EDI.equals(docType)) return this::saveEDICosmosDocument;
        else if (Document.OPS.equals(docType)) return this::saveOpsCosmosDocument;
        else if (Document.GOODS.equals(docType)) return this::saveGoodsItemCosmosDocument;
        else if (Document.ITEM.equals(docType)) return this::saveConsignmentItemCosmosDocument;
        else return null;
    }

    public String getPublishingTopic(String docType) {
        if (Document.EDI_ENRICHER.equals(docType)) return "ph-oem-ee-transport-order";
        else return null;
    }

    public Document mbConsDoc() {
        return getDoc(new Document.DocID(Document.MBCONS, 0, null));
    }

    public Document getDocument(String docType) {
        return getDoc(new Document.DocID(docType, 0, null));
    }

    public Document getDocumentById(String docId) {
        return getDoc(new Document.DocID(docId, 0, null));
    }

    public void sendKafkaMessage(String payload) throws Exception {
        kafkaTemplate.send(topicName, payload).get();
        LOG.info("Message sent for consignment:" + consignmentNo);
        //TODO : LOG.info("Message sent : " + payload);
        System.out.println("Message sent : " + payload);
        if (CollectionUtils.isEmpty(consignmentItemNos)) {
            await();
        } else {
            await(2);
        }
    }

    public void sendKafkaMessageToTopic(String topic, String payload) throws Exception {
        kafkaTemplate.send(topic, payload).get();
        LOG.info("Message sent for consignment:" + consignmentNo);
        //TODO : LOG.info("Message sent : " + payload);
        System.out.println("Message sent : " + payload);
        if (CollectionUtils.isEmpty(consignmentItemNos)) {
            await();
        } else {
            await(2);
        }
    }

    public void sendKafkaMessage(String docType, String payload) throws Exception {
        kafkaTemplate.send(getPublishingTopic(docType), payload).get();
        StringBuilder stringBuilder = new StringBuilder("Message sent for consignment with ");
        if (StringUtils.isNotBlank(consignmentNo)) {
            stringBuilder.append("consignmentNo:").append(consignmentNo);
        } else if (StringUtils.isNotBlank(consItemNo)) {
            stringBuilder.append("consItemNo:").append(consItemNo);
        }
        LOG.info(stringBuilder.toString());
        if (CollectionUtils.isEmpty(consignmentItemNos)) {
            await();
        } else {
            await(2);
        }
        ConsignmentPublishObject consignmentPublishObject = publishMessageConsumer.getConsignmentPublishObject();

        if (consignmentPublishObject != null && this.identifierGenerationType.equalsIgnoreCase(IDENTIFIER_GENERATOR_CONS_ITEM)) {
            this.consignmentNo = consignmentPublishObject.getConsignmentNo();
            LOG.info("Received consignmentNo:{}", this.consignmentNo);
        }
    }

    public void saveEDICosmosDocument(String ediConsDocument) {
        try {
            no.posten.ph.oem.consignment.domain.Consignment cosmosEdiCons = objectMapper.readValue(ediConsDocument, no.posten.ph.oem.consignment.domain.Consignment.class);
            cosmosRepositoryService.saveEdiConsignment(cosmosEdiCons);
        } catch (Exception ex) {
            LOG.error("Exception saving EDI document : " + ex.getMessage());
        }
    }

    public void saveOpsCosmosDocument(String opsConsDocument) {
        try {
            no.posten.ph.oem.consignment.domain.OpsConsignment cosmosOpsCons = objectMapper.readValue(opsConsDocument, no.posten.ph.oem.consignment.domain.OpsConsignment.class);
            cosmosRepositoryService.saveOpsConsignment(cosmosOpsCons);
        } catch (Exception ex) {
            LOG.error("Exception saving Ops document : " + ex.getMessage());
        }
    }

    public void saveGoodsItemCosmosDocument(String goodItemDocument) {
        try {
            no.posten.ph.oem.consignment.domain.GoodsItem cosmosGoodsItem = objectMapper.readValue(goodItemDocument, no.posten.ph.oem.consignment.domain.GoodsItem.class);
            cosmosRepositoryService.saveGoodsItem(cosmosGoodsItem);
        } catch (Exception ex) {
            LOG.error("Exception saving GoodsItem document : " + ex.getMessage());
        }
    }

    public void saveConsignmentItemCosmosDocument(String itemDocument) {
        try {
            ConsignmentItemCosmos cosmosItem = objectMapper.readValue(itemDocument, ConsignmentItemCosmos.class);
            cosmosItemRepositoryService.saveConsignmentItem(cosmosItem);
        } catch (Exception ex) {
            LOG.error("Exception saving ConsItem document : " + ex.getMessage());
        }
    }

    public void saveCosmosDocument(String fileName, Document.DocID docID) throws Exception {
        Document doc = createDoc(docID);
        doc.setBaselineDocument(createMessageFromFile("existing/" + fileName));
        doc.saveDocument();
    }

    public String createMessageFromFile(String fileName) throws IOException {
        LOG.trace("Absolute path for existing :" + resourceLoader.getResource("classpath:data/" + fileName).getURL());
        File resource = resourceLoader.getResource("classpath:data/" + fileName).getFile();
        return Files.readString(resource.toPath(), StandardCharsets.UTF_8);
    }

    public void compareDocumentNull(String actualDocument) {
        executables.add(() -> assertNull(actualDocument));
    }

    public void verifyWarningCodesInPublishedMessages(List<String> arg0) {
        executables.add(() -> assertTrue("Message is not published for consignment", publishMessageConsumer.getConsignmentPublishObject() != null));
        List<String> finalActualErrorCodes = publishMessageConsumer.getErrorCodes();
        executables.add(() -> assertThat("Expected warning codes ", finalActualErrorCodes, hasItems(arg0.toArray(new String[0]))));
    }

    public void verifyWarningCodesNotInPublishedMessages(List<String> arg0) {
        executables.add(() -> assertTrue("Message is not published for consignment", publishMessageConsumer.getConsignmentPublishObject() != null));
        List<String> finalActualErrorCodes = publishMessageConsumer.getErrorCodes();
        arg0.forEach(code ->
                executables.add(() -> assertThat("Unexpected warning codes ", finalActualErrorCodes, not(hasItem(code)))));
    }

    public void verifyErrorCodesInDLT(List<String> arg0) throws Exception {
        executables.add(() -> assertNotNull("Kafka headers not found on DLT Message", deadLetterConsumer.getKafkaHeaders()));
        List<String> actualErrorCodes = this.deadLetterConsumer.getKafkaHeaders().getDLTErrorCodes();
        LOG.debug("Dead letter headers for error codes " + actualErrorCodes);
        executables.add(() -> assertThat("Expected warning codes ", actualErrorCodes, hasItems(arg0.toArray(new String[0]))));
        assertAll();
    }

    public void assertAll() throws InterruptedException {
        Assertions.assertAll(executables);
    }


    public Map<String, Object> getVasObjects(Map<String, String> row, String vasCode) {
        Map<String, Object> vas = new HashMap<>();
        Boolean consVas = Boolean.parseBoolean(row.get("isConsVAS"));
        Boolean active = Boolean.parseBoolean(row.get("active"));
        vas.put("vasCd", vasCode);
        vas.put("isConsVAS", consVas);
        vas.put("active", active);
        return vas;
    }

    public Map<String, Object> getVasObjectsFromMbVas(Map map, boolean isItem) {
        Map<String, Object> vas = new HashMap<>();
        Boolean consVas = Boolean.TRUE;
        Boolean active = Boolean.TRUE;
        vas.put("vasCd", map.get("vasCode"));
        vas.put("isConsVAS", consVas);
        vas.put("active", active);
        if (map.get("serviceRequirements") != null)
            vas.put("svcReqs", map.get("serviceRequirements"));
        if (map.get("discountPercent") != null) {
            if (isItem) {
                vas.put("discPct", map.get("discountPercent"));
            } else {
                vas.put("discPct", Integer.parseInt((String) map.get("discountPercent")));
            }
        }

        if (isItem) {
            vas.put("crtdTs", "2021-12-13T09:09:23.343042969Z");
            vas.put("crtdSvcId", "EPR");
            vas.put("modSvcId", "EPR");
        }
        return vas;
    }
}

package no.posten.ph.testing.automation.bdd.domain;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.JacksonJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.function.Executable;
import org.skyscreamer.jsonassert.Customization;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.comparator.CustomComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 * This class should try to abstract the JSON handling from rest of the program
 * and generic enough to be used for any JSON file
 */
public class JsonFields {
    Map<String,Object> jsonFields = new HashMap<>();
    ObjectMapper objectMapper;
    Document.DocID docId;
    static final Logger LOG = LoggerFactory.getLogger(JsonFields.class);
    static final Configuration jacksonConfig = Configuration
            .builder()
            .mappingProvider( new JacksonMappingProvider() )
            .jsonProvider( new JacksonJsonProvider() )
            .build()
            .addOptions(Option.DEFAULT_PATH_LEAF_TO_NULL)
            .addOptions(Option.SUPPRESS_EXCEPTIONS);

    public JsonFields(ObjectMapper objectMapper, Document.DocID docId){
        this.objectMapper = objectMapper;
        this.docId = docId;
    }

    public void addFieldValue(String path, Object value){
        Object updatedValue = value;
        if ("NULL".equals(value)) updatedValue = null;
        if (value instanceof String s){
            if ((path!=null) && (!StringUtils.isEmpty(s))) if ("".equals(path)) jsonFields.put("$",updatedValue); else jsonFields.put("$."+path,updatedValue);
        } else {
            if (path!=null) if ("".equals(path)) jsonFields.put("$"+path,updatedValue); else jsonFields.put("$."+path,updatedValue);
        }

    }

    String updateFields(String inputJson){
        DocumentContext jsonContext = JsonPath.using(jacksonConfig).parse(inputJson);
        if (jsonFields !=null)
            jsonFields.forEach((key, value)->{
                Object obj = jsonContext.read(key);
                // TODO Currently we only support updating the whole value for the first path matching in case where the jsonPath has filters like parties[?(@.type=='Consignor')]
                if ((obj instanceof List) && (!key.contains("["))){
                    // In case that the List already exists in baseline Json then add the elements to existing list else add a new list with all elements
                    if (value instanceof List values){
                        values.forEach(value2->jsonContext.add(key,value2));
                    } else {
                        jsonContext.add(key,value);
                    }
                } else {
                    jsonContext.set(key, value);
                }
            });
        return  jsonContext.jsonString();
    }

    public List<Executable> verifyFieldsInDocument(String actualDocument, List<Customization> customizations){
        List<Executable> executables = new ArrayList<>();
        executables.add(() -> assertNotNull(docId + " Document expected but not found",actualDocument));
        if (actualDocument!=null) {
            this.jsonFields.forEach((path, value) -> {
                String actualDoc = getSubDocumentAtPath(actualDocument,path);
                String expectedDoc = getDocumentFromObject(value);
                executables.addAll(compareJsonDocument(docId+"-"+path,actualDoc,expectedDoc,customizations));
            });
        }
        return executables;
    }

    public List<Executable> compareJsonDocument(String docName, String actualDoc, String expectedDoc, List<Customization> customizations){
        List<Executable> executables = new ArrayList<>();
        if ((actualDoc!=null) || (expectedDoc!=null)) {
            executables.add(() -> assertNotNull(docName + " document actual value not found", actualDoc));
            executables.add(() -> assertNotNull(docName + " document expected value not supplied", expectedDoc));
            if ((actualDoc != null) && (expectedDoc != null)) {
                executables.add(() -> {
                    try {
                        JSONAssert.assertEquals(docName + " document comparison failed", expectedDoc, actualDoc, new CustomComparator(JSONCompareMode.STRICT
                                , customizations.toArray(new Customization[customizations.size()])));
                    } catch (JSONException jsonException) {
                        /**
                         * For comparing other than string or json
                         */
                        if (jsonException.getMessage().contains("Unparsable JSON string:")) {
                            Assertions.assertEquals(expectedDoc, actualDoc, docName + " document comparison failed");
                        }
                    }
                });
            }
        }
        return executables;
    }

    public String getDocumentFromObject(Object object){
        if (object !=null) {
            try {
                return objectMapper.writeValueAsString(object);
            } catch (JsonProcessingException e) {
                LOG.debug("Object " + object + " not renderable");
            }
        }
        return null;
    }

    public String getSubDocumentAtPath(String inputDoc,String path){
        Object actual = getObjectAtPath(inputDoc,path,false);
        return getDocumentFromObject(actual);
    }


    public Object getObjectAtPath(String inputDoc, String path, boolean returnArray){
        DocumentContext jsonContext = JsonPath.using(jacksonConfig).parse(inputDoc);
        Object object =  jsonContext.read(path);
        if (returnArray) return object;
        // Get the first object since for the filter paths the query always return list of objects
        if (object instanceof List) {
            List array = (List) object;
            if (array.size()>0)
                object = array.get(0);
            else object = null;
        }
        return object;
    }

    public String addDocumentAtPath(String inputDoc,String path, String childDoc){
        DocumentContext docContext = JsonPath.using(jacksonConfig).parse(inputDoc);
        JsonPath pathToArray = JsonPath.compile("$." + path);
        List array = docContext.read(pathToArray);
        if (array == null) {
            docContext.set(pathToArray, new ArrayList<>());
        }
        JsonNode node = JsonPath.using(jacksonConfig).parse(childDoc).read("$", JsonNode.class);
        docContext.add(pathToArray, node);
        return docContext.jsonString();
    }

    public boolean isEmpty(){
        return jsonFields.isEmpty();
    }

}

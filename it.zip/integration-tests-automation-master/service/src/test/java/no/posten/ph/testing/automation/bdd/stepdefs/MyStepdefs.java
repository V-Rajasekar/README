package no.posten.ph.testing.automation.bdd.stepdefs;

import static org.junit.Assert.assertNull;

import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import no.posten.ph.testing.automation.bdd.domain.Document;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

/**
 * This class should deal with the step definitions
 * This class should hide idiosyncrasies related to getting NULL data and other special values
 * from feature files and hide from other classes
 * Should attempt more generic steps if possible to be reusable beyond EDI where possible
 */
public class MyStepdefs extends SpringIntegrationTest {
    static final Logger LOG = LoggerFactory.getLogger(MyStepdefs.class);
    //public record DocID(String docType, int index) {} // Can we move this inside document ?
    static Pattern pattern = Pattern.compile("(\\w+):?(\\d+)?.?(\\w+)?");

    @Given("A random consignmentNumber with testcase number {string}")
    public void aRandomConsignmentNumberWithTestcaseNumber(String arg0) {
        createARandomConsignmentNo(arg0);
    }

    @Given("An identifier generation type {string} create a random identifiers with testcase number {string}")
    public void aRandomConsignmentIdentiferByGenerationType(String identifierGenerationType,
                                                            String testCaseNo) {
        createConsIdentifierWithARandomNo(identifierGenerationType, testCaseNo);
    }

    @When("consumer sends a EDI message {string}")
    public void consumerSendsAEDIMessage(String arg0) throws Exception {
        String inputMsg = createMessageFromFile("input/" + arg0);
        mbConsDoc().setBaselineDocument(inputMsg);
        final var payload = mbConsDoc().getExpectedDocument();
        consignmentItemNos = mbConsDoc().getConsignmentItemNos();
        if (!CollectionUtils.isEmpty(consignmentItemNos)) {
            consignmentItemNo = consignmentItemNos.get(0);
        }
        LOG.info("Request processed for consignment item number : " + consignmentItemNo + " for testCaseNo " + testCaseNo);
        sendKafkaMessage(payload);
    }

    @When("sender sends {string} document {string}")
    public void senderSendsDocumentOfType(String docType, String message) throws Exception {
        String inputMsg = createMessageFromFile("input/" + message);
        Document documentOfType = getDocument(docType);
        documentOfType.setBaselineDocument(inputMsg);
        sendKafkaMessage(docType, documentOfType.getExpectedDocument());
    }

    /**
     * Below steps are for handling messages received on topics
     * TODO add handling for the consignment item publish topic and then remove tne 3 seconds sleep
     */
    @And("no message to send to DLT")
    public void noMessageToSendToDLT() throws Exception {
        executables.add(() -> assertNull("Message not expected on DLT", deadLetterConsumer.getKafkaHeaders()));
        assertAll();
    }

    @And("a message to send to DLT with errorCode {string}")
    public void aMessageToSendToDLTWithErrorCode(String arg0) throws Exception {
        verifyErrorCodesInDLT(splitCommaDelimitedCodes(arg0));
    }

    @And("a consignment is published with warningCode {string}")
    public void aConsignmentIsPublishedWithWarningCode(String arg0) throws Exception {
        verifyWarningCodesInPublishedMessages(splitCommaDelimitedCodes(arg0));
    }

    @Then("a consignment is published does not contain warningCode {string}")
    public void aConsignmentIsPublishedDoesNotContainWarningCode(String arg0) throws Exception {
        verifyWarningCodesNotInPublishedMessages(splitCommaDelimitedCodes(arg0));
    }

    /**
     * Below steps are for verifying/saving the documents in cosmos
     */
    @Then("{string} documents saved in cosmosDB matches {string}")
    public void documentsSavedInCosmosDBMatches(String documentType, String arg1) throws Exception {
        String file = createMessageFromFile("output/" + arg1);
        Document doc = getDocuments(documentType).get(0);
        doc.setBaselineDocument(file);
        executables.addAll(doc.verifyAll());
    }

    @Then("verify the {string} documents in Cosmos")
    public void verifyTheDocumentsInCosmos(String arg0) {
        getDocuments(arg0).forEach(d -> executables.addAll(d.verifyAll()));
    }

    @Then("no {string} documents are saved to cosmosDb for consignment")
    public void noDocumentsAreSavedToCosmosDbForConsignment(String arg0) {
        getDocuments(arg0).forEach(d -> compareDocumentNull(d.getActualDocument()));
    }

    @And("Cosmos has {string} document like {string}")
    public void cosmosHasDocumentLike(String docType, String file) throws Exception {
        saveCosmosDocument(file, getDocID(docType));
    }

    @And("Cosmos has the documents {string} ,  {string}, {string}")
    public void cosmosHasTheDocuments(String ediFile, String opsFile, String goodItemFile) throws Exception {
        saveCosmosDocument(ediFile, new Document.DocID(Document.EDI, 0, null));
        saveCosmosDocument(opsFile, new Document.DocID(Document.OPS, 0, null));
        saveCosmosDocument(goodItemFile, new Document.DocID(Document.GOODS, 0, null));
    }

    /**
     * Below steps are for adding changes to the baseline document
     */
    @Then("we expect {string} document with the following data")
    public void weExpectDocumentWithTheFollowingData(String arg0, DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        addChangesToDocumentWithDataType(data, getDocuments(arg0));
    }

    @When("we add {string} consignmentItem like {string}")
    public void weAddConsignmentItemLike(String numOfItems, String referenceConsItemFile) throws Exception {
        int noOfItems = Integer.parseInt(numOfItems);
        String inputMsg = createMessageFromFile("input/" + referenceConsItemFile);
        for (int i = 1; i <= noOfItems; i++) {
            Document.DocID docID = new Document.DocID(Document.MBCONS, 0, "item-" + i);
            Document itemDocument = createDoc(docID);
            itemDocument.setBaselineDocument(inputMsg);
            mbConsDoc().addChildDocuments("goodsItem[0].consignmentItems", itemDocument);
        }
    }

    /**
     * Below steps are for handling Vases
     */

    @And("additional VAS with vasCode {string} and serviceRequirements {string} and discountPercent {string}")
    public void additionalVASWithVasCodeAndServiceRequirementsAndDiscountPercent(String vasCodes, String serviceRequirement, String discount) {
        List<Map<String, Object>> vasList = new ArrayList<>();
        final var serviceRequirements = splitCommaDelimitedCodes(serviceRequirement);
        final var vasDiscounts = splitCommaDelimitedCodes(discount);
        splitCommaDelimitedCodes(vasCodes).stream().forEach(vasCode -> {
            Map<String, Object> vas = new HashMap<>();
            vas.put("vasCode", vasCode);
            vas.put("serviceRequirements", serviceRequirements.get(0));
            vas.put("discountPercent", vasDiscounts.get(0));
            vasList.add(vas);
        });

        for (int i = 1; i < serviceRequirements.size(); i++) {
            vasList.get(i).put("serviceRequirements", serviceRequirements.get(i));
        }
        for (int i = 1; i < vasDiscounts.size(); i++) {
            vasList.get(i).put("discountPercent", vasDiscounts.get(i));
        }
        mbConsDoc().getFields().addFieldValue("vas", vasList);
    }

    @Then("we expect the following vas on the {string} documents")
    public void weExpectTheFollowingVasOnTheDocuments(String arg0, DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> row : data) {
            if (StringUtils.isNotBlank(row.get("vasCd"))) {
                String vasCodes = row.get("vasCd");
                splitCommaDelimitedCodes(vasCodes).stream().forEach(vasCode -> {
                    Map<String, Object> vas = getVasObjects(row, vasCode);
                    getDocuments(arg0).forEach(d -> {
                        Document.DocID docID = new Document.DocID(d.getDocId().docType(), d.getDocId().docIndex(), "-vas-" + vas.get("vasCd"));
                        Document child = createDoc(docID);
                        switch (docID.docType()) {
                            case "ConsItem":
                                vas.put("crtdTs", "2021-12-13T09:09:23.343042969Z");
                                vas.put("crtdSvcId", "EPR");
                                break;
                        }
                        child.getFields().addFieldValue("", vas);
                        d.addChildDocuments("vas[?(@.vasCd=='" + vas.get("vasCd") + "')]", child);
                    });
                });
            }
        }
    }

    @Then("verify the vases {string} are not added on {string} documents")
    public void verifyTheVasesAreNotAddedOnDocuments(String vasCodes, String arg1) {
        if (!StringUtils.isEmpty(vasCodes)) {
            for (String vasCd : splitCommaDelimitedCodes(vasCodes)) {
                //TODO avoid using "NULL" value for hte jsonUpdate value
                getDocuments(arg1).forEach(d -> d.getFields().addFieldValue("vas[?(@.vasCd=='" + vasCd + "')]", "NULL"));
            }
        }
    }

    @Then("we expect the following vas on the {string} documents on top of input vases")
    public void weExpectTheFollowingVasOnTheDocumentsOnTopOfInputVases(String arg0, DataTable dataTable) {
        Object actual = mbConsDoc().getFields().getObjectAtPath(mbConsDoc().getBaselineDocument(), "vas", true);
        if (actual instanceof List) {
            List array = (List) actual;
            for (Object inputVas : array) {
                if (inputVas instanceof Map) {
                    Map map = (Map) inputVas;
                    Map<String, Object> vas = getVasObjectsFromMbVas(map, arg0.contains("ConsItem"));
                    getDocuments(arg0).forEach(d -> d.getFields().addFieldValue("vas[?(@.vasCd=='" + map.get("vasCode") + "')]", vas));
                }
            }
        }
        //TODO convert all VAS comparisons to child documents refactoring
        weExpectTheFollowingVasOnTheDocuments(arg0, dataTable);
    }

    @Then("consumer sends a CBM message with following values")
    public void weExpectDocumentWithTheFollowingData(DataTable dataTable) throws Exception {
        List<Map<String, String>> cbmFields = dataTable.asMaps(String.class, String.class);
        String cbmBaseXml = createMessageFromFile("input/" + "cbm_base_message.xml");
        String payload = createCBMInputXMl(cbmFields, cbmBaseXml);
        LOG.info("Request processed for consignment item number : " + consItemNo + " for testCaseNo " + testCaseNo);
        sendKafkaMessageToTopic("ph-oem-ord-transportorder-cbm", payload);
    }


    /**
     * Below steps are for handling parsing of the data from the steps like multiple documents, vas, tables with datatype, error codes
     */

    public List<String> splitCommaDelimitedCodes(String codes) {
        if (StringUtils.isNotBlank(codes)) {
            if (codes.contains(",")) {
                return Arrays.stream(codes.split(",")).toList();
            } else return List.of(codes);
        } else {
            return List.of();
        }
    }

    public void addChangesToDocumentWithDataType(List<Map<String, String>> data, List<Document> docs) {
        docs.forEach(doc -> {
            data.forEach(field -> {
                if ("num".equalsIgnoreCase(field.get("dataType"))) {
                    doc.getFields().addFieldValue(field.get("fieldPath"), new BigDecimal(field.get("fieldName")));
                } else if ("bool".equalsIgnoreCase(field.get("dataType"))) {
                    doc.getFields().addFieldValue(field.get("fieldPath"), Boolean.valueOf(field.get("fieldName")));
                } else if (StringUtils.isNotBlank(field.get("fieldName"))) {
                    doc.getFields().addFieldValue(field.get("fieldPath"), field.get("fieldName"));
                }
            });
        });
    }

    public List<Document> getDocuments(String docs) {
        return getDocIDs(docs).stream().map(this::getDoc).toList();
    }

    public List<Document.DocID> getDocIDs(String docs) {
        if (docs.contains(",")) {
            return Arrays.stream(docs.split(",")).map(d -> getDocID(d)).toList();
        } else return List.of(getDocID(docs));
    }

    public static Document.DocID getDocID(String doc) {
        Matcher matcher = pattern.matcher(doc);
        matcher.find();
        int index = 0;
        if (matcher.group(2) != null) index = Integer.parseInt(matcher.group(2));
        return new Document.DocID(matcher.group(1), index, matcher.group(3));
    }

    public Document getDoc(String docIdString) {
        return getDoc(getDocID(docIdString));
    }

    public String createCBMInputXMl(List<Map<String, String>> inputFieldList, String baseXml) throws Exception {
        StringWriter writer = new StringWriter();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            InputSource inputSource = new InputSource();
            inputSource.setCharacterStream(new StringReader(baseXml));
            org.w3c.dom.Document doc = builder.parse(inputSource);
            Element root = doc.getDocumentElement();
            Element dataNode = doc.createElement("data");
            for (Map<String, String> inputFieldValueMap : inputFieldList) {
                Element field = doc.createElement(inputFieldValueMap.get("fieldName"));
                field.appendChild(doc.createTextNode(inputFieldValueMap.get("fieldValue")));
                dataNode.appendChild(field);
            }
            root.appendChild(dataNode);
            DOMSource domSource = new DOMSource(doc);
            StreamResult result = new StreamResult(writer);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.transform(domSource, result);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return writer.toString();
    }
}

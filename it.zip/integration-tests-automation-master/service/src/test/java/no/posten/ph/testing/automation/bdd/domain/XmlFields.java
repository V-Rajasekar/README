package no.posten.ph.testing.automation.bdd.domain;

import no.posten.ph.oem.cbm.adapter.consumer.schemas.jaxb.X0420PShipmentEventInfoImport;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class XmlFields {

    static final Logger LOG = LoggerFactory.getLogger(XmlFields.class);
    Marshaller marshaller;
    Document.DocID docId;
    Unmarshaller unmarshaller;
    List<Map<String, String>> changeFields;
    private static JAXBContext jaxbContext;

    static {
        try {
            jaxbContext = JAXBContext.newInstance(X0420PShipmentEventInfoImport.class);
        } catch (JAXBException jxb) {
            throw new RuntimeException(jxb);
        }
    }

    // Parameterized constructor
    public XmlFields(Marshaller marshaller, Document.DocID docId, Unmarshaller unmarshaller) {
        this.marshaller = marshaller;
        this.docId = docId;
        this.unmarshaller = unmarshaller;
    }

    // Default constructor
    public XmlFields() {

    }

    public XmlFields getXMLField() {
        try {
            return new XmlFields(jaxbContext.createMarshaller(), docId, jaxbContext.createUnmarshaller());
        } catch (Exception exception) {
            LOG.debug("Exception while initializing XML Fields", exception.getStackTrace());
        }
        return null;
    }

    X0420PShipmentEventInfoImport x0420PShipmentEventInfoImport;

    private void cbmXmlNodes(String baselineXml) throws JAXBException {

        InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(baselineXml.getBytes()),
                StandardCharsets.UTF_8);
        Source source = new StreamSource(inputStreamReader);
        x0420PShipmentEventInfoImport = unmarshaller.unmarshal(source, X0420PShipmentEventInfoImport.class).getValue();
    }

    public String getExpectedCBMXML(String baselineXml) throws Exception {
        cbmXmlNodes(baselineXml);
        if (CollectionUtils.isNotEmpty(changeFields)) {
            StringWriter writer = new StringWriter();
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            try {
                builder = factory.newDocumentBuilder();
                InputSource inputSource = new InputSource();
                inputSource.setCharacterStream(new StringReader(baselineXml));
                org.w3c.dom.Document doc = builder.parse(inputSource);
                for (Map<String, String> changedFields : changeFields) {
                    for (String attribute : changedFields.keySet()) {
                        NodeList data = doc.getElementsByTagName(changedFields.get("fieldName"));
                        for (int i = 0; i < data.getLength(); i++) {
                            data.item(i).getFirstChild().setNodeValue(changedFields.get("fieldValue"));
                        }
                    }
                }
                DOMSource domSource = new DOMSource(doc);
                StreamResult result = new StreamResult(writer);
                TransformerFactory tf = TransformerFactory.newInstance();
                Transformer transformer = tf.newTransformer();
                transformer.transform(domSource, result);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return writer.toString();
        } else {
            return baselineXml;
        }
    }

    public void setChangeFields(List<Map<String, String>> changeFields) {
        this.changeFields = changeFields;
    }
}

package no.posten.ph.testing.automation.bdd.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import no.posten.ph.oem.consignmentitem.api.model.ConsignmentItem;
import no.posten.ph.oem.edi.consignment.consumer.model.ConsignmentPublishObject;
import no.posten.ph.oem.edi.consignmentitem.consumer.mapper.ConsignmentItemPublishMessage;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

@Component
@Profile("bdd")
public class ConsItemPublishMessageConsumer {
    static final Logger LOG = LoggerFactory.getLogger(ConsItemPublishMessageConsumer.class);
    private CountDownLatch latch = new CountDownLatch(1);
    private String payload = null;
    private String originalPayload = null;
    private Headers headers = null;
    private Headers originalHeaders = null;
    private ConsignmentItem consignmentItem;
    private ConsignmentItem originalConsignmentItem;
    private String consignmentItemNo;
    private String originalConsignmentItemNo;

    @Autowired
    ObjectMapper objectMapper;

    @KafkaListener(topics = "${spring.kafka.consumer.consItemPublishtopic}", groupId = ("${spring.kafka.consumer.group-id}"))
    public void onMessage(ConsumerRecord<String, String> consumerRecord) {
        try {
            if ((consumerRecord != null) && (consumerRecord.value() != null)) {
                ConsignmentItemPublishMessage consignmentItemPublishObject = objectMapper.readValue(consumerRecord.value(), ConsignmentItemPublishMessage.class);
                LOG.info("Response message - Consignment Item number : {} and consignment no : {} ", consignmentItemPublishObject.getConsignmentItem().getConsItemNo(),
                        consignmentItemPublishObject.getConsignmentItem().getConsignmentNo());
                if ((this.consignmentItemNo != null) && (this.consignmentItemNo.equals(consignmentItemPublishObject.getConsignmentItem().getConsItemNo()))) {
                    this.headers = consumerRecord.headers();
                    this.payload = consumerRecord.value();
                    this.consignmentItem = consignmentItemPublishObject.getConsignmentItem();
                    if (this.latch != null) this.latch.countDown();
                }
                if ((this.originalConsignmentItemNo != null) && (this.originalConsignmentItemNo.equals(consignmentItemPublishObject.getConsignmentItem().getConsItemNo()))) {
                    this.originalHeaders = consumerRecord.headers();
                    this.originalPayload = consumerRecord.value();
                    this.originalConsignmentItem = consignmentItemPublishObject.getConsignmentItem();
                    if (this.latch != null) this.latch.countDown();
                }
            }
        } catch (JsonProcessingException e) {
            LOG.error("Error parsing the output message: ", e);
        }

    }

    public void setContext(String consignmentItemNo, String originalConsignmentItemNo, CountDownLatch countDownLatch) {
        this.consignmentItemNo = consignmentItemNo;
        this.originalConsignmentItemNo = originalConsignmentItemNo;
        this.latch = countDownLatch;
    }

    public void clearContext() {
        LOG.debug("Clearing context for the Publish consumer");
        this.consignmentItemNo = null;
        this.originalConsignmentItemNo = null;
        this.headers = null;
        this.payload = null;
        this.consignmentItem = null;
        this.originalHeaders = null;
        this.originalPayload = null;
        this.originalConsignmentItem = null;
        this.latch = null;
    }


    public Headers getHeaders() {
        return headers;
    }

    public ConsignmentItem getConsignmentItem() {
        try {
            LOG.debug("Document on published topic = " + objectMapper.writeValueAsString(consignmentItem));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return consignmentItem;
    }

    public Headers getOriginalHeaders() {
        return originalHeaders;
    }

    public ConsignmentItem getOriginalConsignmentItem() {
        return originalConsignmentItem;
    }
}

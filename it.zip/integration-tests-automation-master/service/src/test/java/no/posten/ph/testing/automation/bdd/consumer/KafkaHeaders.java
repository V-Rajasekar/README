package no.posten.ph.testing.automation.bdd.consumer;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import no.posten.ph.oem.edi.consignment.consumer.model.ValidationError;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class KafkaHeaders {
    String failCodeDetails;
    String originalTopic;
    String exceptionMessage;
    String exceptionStacktrace;
    String exceptionFqcn;
    String exceptionType;
    String correlationId;
    ObjectMapper objectMapper;
    //String retryCount;
    //String originalTimestamp;
    static final String failCodeDetails_header = "DLT_FAIL_CODE_DETAILS";
    static final String originalTopic_header ="kafka_dlt-original-topic";
    static final String exceptionMessage_header = "kafka_dlt-exception-message";
    static final String exceptionStacktrace_header="kafka_dlt-exception-stacktrace";
    static final String exceptionFqcn_header = "kafka_dlt-exception-fqcn";
    static final String exceptionType_header = "DLT_EXCEPTION_TYPE";
    static final String correlationId_header = "kafka_correlationId";
    static final String retryCount_header = "DLT_RETRY_COUNT";
    static final String originalTimestamp_header = "kafka_dlt-original-timestamp";

    private static final Logger LOG = LoggerFactory.getLogger(KafkaHeaders.class);

    public KafkaHeaders(Headers headers, ObjectMapper objectMapper) {
        headers.forEach(header->{
            switch (header.key()) {
                case "DLT_FAIL_CODE_DETAILS": this.failCodeDetails = new String(header.value()); break;
                case "kafka_dlt-original-topic" : this.originalTopic = new String(header.value()); break;
                case "kafka_dlt-exception-message" : this.exceptionMessage = new String(header.value()); break;
                case "kafka_dlt-exception-stacktrace" : this.exceptionStacktrace = new String(header.value()); break;
                case "kafka_dlt-exception-fqcn" : this.exceptionFqcn = new String(header.value()); break;
                case "DLT_EXCEPTION_TYPE" : this.exceptionType = new String(header.value()); break;
                case "kafka_correlationId" : this.correlationId = new String(header.value()); break;
            }
        });
        this.objectMapper = objectMapper;
    }

    public String getFailCodeDetails() {
        return failCodeDetails;
    }

    public String getOriginalTopic() {
        return originalTopic;
    }

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public String getExceptionStacktrace() {
        return exceptionStacktrace;
    }

    public String getExceptionFqcn() {
        return exceptionFqcn;
    }

    public String getExceptionType() {
        return exceptionType;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public static String getFailCodeDetails_header() {
        return failCodeDetails_header;
    }

    public static String getOriginalTopic_header() {
        return originalTopic_header;
    }

    public static String getExceptionMessage_header() {
        return exceptionMessage_header;
    }

    public static String getExceptionStacktrace_header() {
        return exceptionStacktrace_header;
    }

    public static String getExceptionFqcn_header() {
        return exceptionFqcn_header;
    }

    public static String getExceptionType_header() {
        return exceptionType_header;
    }

    public static String getCorrelationId_header() {
        return correlationId_header;
    }

    public static String getRetryCount_header() {
        return retryCount_header;
    }

    public static String getOriginalTimestamp_header() {
        return originalTimestamp_header;
    }

    @Override
    public String toString() {
        return "KafkaHeaders{" +
                "failCodeDetails='" + failCodeDetails + '\'' +
                ", originalTopic='" + originalTopic + '\'' +
                ", exceptionMessage='" + exceptionMessage + '\'' +
                ", exceptionStacktrace='" + exceptionStacktrace + '\'' +
                ", exceptionFqcn='" + exceptionFqcn + '\'' +
                ", exceptionType='" + exceptionType + '\'' +
                ", correlationId='" + correlationId + '\'' +
                '}';
    }

    public List<String> getDLTErrorCodes(){
        try {
            Set<ValidationError> validationErrors = objectMapper.readValue(this.failCodeDetails, new TypeReference<Set<ValidationError>>() {});
            List<String> actualErrorCodesList = validationErrors.stream().map(e->e.getType()+e.getCode()).collect(Collectors.toList());
            return actualErrorCodesList;
        } catch (Exception e){
            LOG.warn("Failed to get DLT error codes", e);
        }
        return Collections.emptyList();
    }
}

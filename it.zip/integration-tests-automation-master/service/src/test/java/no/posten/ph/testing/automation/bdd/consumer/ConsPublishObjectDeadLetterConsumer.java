package no.posten.ph.testing.automation.bdd.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import no.posten.ph.oem.edi.consignment.consumer.model.ConsignmentPublishObject;
import no.posten.ph.testing.automation.consumer.model.Consignment;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.CountDownLatch;

@Component
@Profile("bdd")
public class ConsPublishObjectDeadLetterConsumer {
    static final Logger LOG = LoggerFactory.getLogger(ConsPublishObjectDeadLetterConsumer.class);

    private CountDownLatch latch = new CountDownLatch(1);
    private String payload = null;
    private Headers headers = null;
    private ConsignmentPublishObject consignment;
    private String consignmentNo;
    private KafkaHeaders kafkaHeaders;

    @Autowired
    ObjectMapper objectMapper;

    @KafkaListener(topics = "${spring.kafka.consumer.deadlettertopic}", groupId = ("${spring.kafka.consumer.group-id}"))
    public void onMessage(ConsumerRecord<String, String> consumerRecord) {
        try {
            if ((consumerRecord != null) && (consumerRecord.value() != null)) {
                ConsignmentPublishObject consignment = objectMapper.readValue(consumerRecord.value(), ConsignmentPublishObject.class);
                LOG.info("DeadLetter ConsPublishObject message - Consignment number: " +
                        consignment.getConsignmentNo());
                if ((this.consignmentNo != null) && (this.consignmentNo.equals(consignment.getConsignmentNo()))) {
                    setHeaders(consumerRecord);
                    this.payload = consumerRecord.value();
                    this.consignment = consignment;
                    if (this.latch != null) this.latch.countDown();
                }
            }
        } catch (JsonProcessingException e) {
            LOG.error("Error parsing the output message: ", e);
        }
    }

    public void setHeaders(ConsumerRecord<String, String> consumerRecord) {
        this.headers = consumerRecord.headers();
        this.kafkaHeaders = new KafkaHeaders(consumerRecord.headers(), objectMapper);
    }

    public void clearContext() {
        LOG.debug("Clearing context for the Deadletter consumer");
        this.consignmentNo = null;
        this.headers = null;
        this.kafkaHeaders = null;
        this.payload = null;
        this.consignment = null;
        this.latch = null;
    }

    public void setContext(String consignmentNo, CountDownLatch countDownLatch) {
        this.consignmentNo = consignmentNo;
        this.latch = countDownLatch;
    }

    public Headers getHeaders() {
        return headers;
    }

    public CountDownLatch getLatch() {
        return latch;
    }

    public ConsignmentPublishObject getPayload() {
        return consignment;
    }


    public KafkaHeaders getKafkaHeaders() {
        return kafkaHeaders;
    }

    public void setKafkaHeaders(KafkaHeaders kafkaHeaders) {
        this.kafkaHeaders = kafkaHeaders;
    }

}

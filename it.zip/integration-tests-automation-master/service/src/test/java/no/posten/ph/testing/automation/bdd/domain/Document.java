package no.posten.ph.testing.automation.bdd.domain;

import com.fasterxml.jackson.databind.ObjectMapper;
import no.posten.ph.testing.automation.bdd.repository.CosmosItemRepositoryService;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.function.Executable;
import org.skyscreamer.jsonassert.Customization;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

import static no.posten.ph.testing.automation.bdd.stepdefs.SpringIntegrationTest.IDENTIFIER_GENERATOR_CONS_ITEM;

/**
 * This class should try to abstract the different documents in the project context and their path related details
 * and can be specific for the a scope but should purely deal in document handling ideally should be able to plug json with XML
 */
public class Document {
    static final Logger LOG = LoggerFactory.getLogger(Document.class);
    public static final String EDI = "EdiCons";
    public static final String OPS = "OpsCons";
    public static final String GOODS = "GoodsItem";
    public static final String ITEM = CosmosItemRepositoryService.DOC_TYPE_CONSIGNMENT_ITEM;
    public static final String MBCONS = "MbEdi";
    public static final String EDI_ENRICHER = "EdiEnricher";
    public static final String CBMCONS = "CbmCons";
    public static final String CHILD = "Child";
    public static final String CONSITEMNO = "consItemNo";
    public static final BigInteger BASELINENUMBER = new BigInteger("1000000000000000000000");
    final List<Customization> customizations = getIgnoredFields();

    final DocID docId;
    private String baselineDocument;
    private String expectedDocument;
    private String actualDocument;

    private JsonFields fields;
    private final Function<String, Object> documentFetcher;
    private final Consumer<String> documentPersister;
    private boolean fetchedActualDocument = false;

    private String identifier;
    private int randomNumber;
    private String parentIdentifier;
    private Map<String, List<Document>> childDocuments;
    private XmlFields xmlFields;


    public record DocID(String docType, int docIndex, String path) {
        @Override
        public String toString () {
            return "Doc " + docType + ":" + docIndex + "." + path;
        }
    }

    private void addStandardDocumentChanges() {
        switch (docId.docType) {
            case "EdiCons", "OpsCons", "GoodsItem":
                fields.addFieldValue("consNo", identifier);
                fields.addFieldValue("id", identifier + ":" + docId.docType);
                break;
            case "ConsItem":
                fields.addFieldValue("consNo", parentIdentifier);
                fields.addFieldValue("id", identifier + ":" + docId.docType);
                fields.addFieldValue("consItemNo", identifier);
                break;
            case "MbEdi":
                fields.addFieldValue("consignmentNo", identifier);
            case EDI_ENRICHER:
                fields.addFieldValue("consItemNo", identifier);
                break;
        }
    }

    public List<String> getConsignmentItemNos() {
        return consignmentItemNos;
    }

    public void setConsignmentItemNos(List<String> consignmentItemNos) {
        this.consignmentItemNos = consignmentItemNos;
    }

    private List<String> consignmentItemNos = new ArrayList<>();

    private void updateConsignmentItemNumbersOnMBDocument() {
        int i = 1;
        Object itemObjects = fields.getObjectAtPath(baselineDocument, "goodsItem[*]", true);
        if (itemObjects != null) {
            if (itemObjects instanceof List) {
                List objList = (List) itemObjects;
                for (int j = 0; j < objList.size(); j++) {
                    Object goodsLineObject = ((List<?>) itemObjects).get(j);
                    if (goodsLineObject != null) {
                        Object consignmentItemObjects = ((Map) goodsLineObject).get("consignmentItems");
                        if (consignmentItemObjects != null) {
                            if (consignmentItemObjects instanceof List) {
                                List itemList = (List) consignmentItemObjects;
                                for (int k = 0; k < itemList.size(); k++) {
                                    String itemNo = BigInteger.valueOf(randomNumber + i).add(BASELINENUMBER).toString();
                                    ;
                                    fields.addFieldValue("goodsItem[" + j + "].consignmentItems[" + k + "].consignmentItemNo", itemNo);
                                    consignmentItemNos.add(itemNo);
                                    i++;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void generateExpectedDocumentWithChanges() {
        if (baselineDocument != null) {
            mergeChildDocumentsToParent();
            if (MBCONS.equals(this.docId.docType)) {
                updateConsignmentItemNumbersOnMBDocument();
            }
            expectedDocument = fields.updateFields(baselineDocument);
        }
    }

    public List<Executable> verifyAll() {
        List<Executable> executables = new ArrayList<>();
        getActualDocument();
        generateExpectedDocumentWithChanges();

        if (childDocuments != null) {
            populateChildDocumentActual();
            childDocuments.forEach((key, children) -> {
                if (children != null) {
                    children.forEach(c -> executables.addAll(c.verifyAll()));
                }
            });
        }
        if (!fields.isEmpty()) {
            if (baselineDocument != null) {
                executables.addAll(fields.compareJsonDocument(docId.toString(), actualDocument, expectedDocument, customizations));
            } else {
                executables.addAll(fields.verifyFieldsInDocument(actualDocument, customizations));
            }
        }
        return executables;
    }

    // Supports only populating the first object in the array due to limitations in getSubDocumentAtPath
    private void populateChildDocumentActual() {
        if (actualDocument != null) {
            childDocuments.forEach((key, documents) -> {
                documents.get(0).setActualDocument(fields.getSubDocumentAtPath(actualDocument, key));
            });
        }
    }

    // Supported only for the paths which are pointing to arrays
    private void mergeChildDocumentsToParent() {
        if (childDocuments != null) {
            String documentString = this.baselineDocument;
            for (String childDocumentsKey : childDocuments.keySet()) {
                for (Document child : this.childDocuments.get(childDocumentsKey)) {
                    child.generateExpectedDocumentWithChanges();
                    documentString = fields.addDocumentAtPath(documentString, childDocumentsKey, child.getExpectedDocument());
                }
            }
            this.baselineDocument = documentString;
        }
    }

    private void fetchDocument() {
        try {
            Object obj = documentFetcher.apply(this.identifier);
            setActualDocument((obj == null) ? null : fields.getDocumentFromObject(obj));
            LOG.trace(docId + " read = " + this.actualDocument);
        } catch (Throwable throwable) {
            LOG.error("Error loading the document : " + docId);
        }
    }

    public void saveDocument() {
        try {
            documentPersister.accept(getExpectedDocument());
            LOG.trace(docId + " Document saved = " + docId);
        } catch (Throwable throwable) {
            LOG.error("Error saving the document : " + docId);
        }
    }

    /**
     * Getter and Setter
     */

    public String getBaselineDocument() {
        return baselineDocument;
    }

    public void setBaselineDocument(String baselineDocument) {
        this.baselineDocument = baselineDocument;
    }

    public String getExpectedDocument() {
        if (expectedDocument == null) {
            generateExpectedDocumentWithChanges();
        }
        return expectedDocument;
    }

    public String getActualDocument() {
        if ((fetchedActualDocument == false) && (documentFetcher != null)) {
            fetchDocument();
            fetchedActualDocument = true;
        }
        return actualDocument;
    }

    public void setActualDocument(String actualDocument) {
        this.actualDocument = actualDocument;
    }

    public JsonFields getFields() {
        return fields;
    }

    public String getIdentifier() {
        return identifier;
    }

    public DocID getDocId() {
        return docId;
    }

    public void addChildDocuments(String key, Document doc) {
        if (this.childDocuments == null)
            this.childDocuments = new HashMap<>();
        if (this.childDocuments.get(key) == null)
            this.childDocuments.put(key, new ArrayList<>());
        this.childDocuments.get(key).add(doc);
    }

    public Document(DocID docID, String identifierGenerationType, String parentIdentifier, int randomNumber,
                    String testCaseNumber, ObjectMapper objectMapper, Function<String, Object> documentFetcher,
                    Consumer<String> persister) {

        this.docId = docID;
        this.randomNumber = randomNumber;
        this.fields = new JsonFields(objectMapper, docId);
        int num = randomNumber;
        this.xmlFields = new XmlFields().getXMLField();
        if (ITEM.equals(docId.docType) && !identifierGenerationType.equalsIgnoreCase(IDENTIFIER_GENERATOR_CONS_ITEM)) {
            parentIdentifier = BigInteger.valueOf(num).add(BASELINENUMBER).toString();
            num = num + docId.docIndex;
        }

        if (identifierGenerationType.equalsIgnoreCase(IDENTIFIER_GENERATOR_CONS_ITEM)
                && StringUtils.isNotBlank(parentIdentifier) && !ITEM.equals(docId.docType)) {
            this.identifier = parentIdentifier;
        } else {
            this.parentIdentifier = parentIdentifier;
            this.identifier = BigInteger.valueOf(num).add(BASELINENUMBER).toString();
        }
        LOG.debug("DocId:{} ParentIdentifier:{} identifier:{} identifierGenerationType:{}", docID.toString(),
                parentIdentifier, identifier,
                identifierGenerationType);
        this.documentFetcher = documentFetcher;
        this.documentPersister = persister;
        if (docID.path() == null) addStandardDocumentChanges();
    }

    public Document(DocID docID, int randomNumber, String testCaseNumber, Marshaller marshaller, Unmarshaller unmarshaller, Function<String, Object> documentFetcher, Consumer<String> persister) {
        this.docId = docID;
        this.randomNumber = randomNumber;
        this.xmlFields = new XmlFields(marshaller, docId, unmarshaller);
        int num = randomNumber;
        if (ITEM.equals(docId.docType)) {
            parentIdentifier = BigInteger.valueOf(num).add(BASELINENUMBER).toString();
            num = num + docId.docIndex;
        }
        this.identifier = BigInteger.valueOf(num).add(BASELINENUMBER).toString();
        this.documentFetcher = documentFetcher;
        this.documentPersister = persister;
        if (docID.path() == null) addStandardDocumentChanges();
    }

    public static List<Customization> getIgnoredFields() {
        final List<Customization> customizations = new ArrayList<>();
        customizations.add(new Customization("consUID", (o1, o2) -> true));
        customizations.add(new Customization("consItemUId", (o1, o2) -> true));
        customizations.add(new Customization("ttl", (o1, o2) -> true));
        customizations.add(new Customization("auditFields.crtdTs", (o1, o2) -> true));
        customizations.add(new Customization("auditFields.modTs", (o1, o2) -> true));
        customizations.add(new Customization("crtdTs", (o1, o2) -> true));
        customizations.add(new Customization("modTs", (o1, o2) -> true));
        customizations.add(new Customization("auditFields.wkNo", (o1, o2) -> true));
        customizations.add(new Customization("msgHeader.tsOrig", (o1, o2) -> true));
        customizations.add(new Customization("msgHeader.ts", (o1, o2) -> true));
        // Delivery dates can be changed in the EDI processing
        customizations.add(new Customization("dateTimes[type=DocumentDate].ts", (o1, o2) -> true));
        customizations.add(new Customization("dateTimes[type=PickupDateEarliest].ts", (o1, o2) -> true));
        // TODO consNoRelab field for a mapping issue in the code
        customizations.add(new Customization("consNoRelab", (o1, o2) -> true));
        customizations.add(new Customization("consItems", (o1, o2) -> true));
        customizations.add(new Customization("vas[*].crtdSvcId", (o1, o2) -> true));
        customizations.add(new Customization("vas[*].crtdTs", (o1, o2) -> true));
        customizations.add(new Customization("vas[*].modSvcId", (o1, o2) -> true));
        customizations.add(new Customization("crtdSvcId", (o1, o2) -> true));
        customizations.add(new Customization("crtdTs", (o1, o2) -> true));
        customizations.add(new Customization("modSvcId", (o1, o2) -> true));
        return customizations;
    }

    public String getExpectedXMLDocument() throws Exception {
        if (expectedDocument == null) {
            generateExpectedDocWithChanges();
        }
        return expectedDocument;
    }

    private void generateExpectedDocWithChanges() throws Exception {
        if (baselineDocument != null) {
            expectedDocument = xmlFields.getExpectedCBMXML(baselineDocument);
        }
    }

    public XmlFields getXmlFields() {
        return xmlFields;
    }

}

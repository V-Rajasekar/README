package no.posten.ph.testing.automation.bdd.stepdefs;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import no.posten.ph.oem.consignment.domain.OpsConsignment;
import no.posten.ph.oem.consignment.domain.OpsConsignmentPartyConsignee;
import no.posten.ph.oem.consignment.domain.OpsConsignmentPartyConsignor;
import no.posten.ph.oem.consignmentitem.api.domain.item.ConsignmentItemCosmos;
import no.posten.ph.oem.consignmentitem.api.domain.item.Vas;
import no.posten.ph.testing.automation.bdd.domain.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.JAXBException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class should deal with the step definitions
 * This class should hide idiosyncrasies related to getting NULL data and other special values
 * from feature files and hide from other classes
 * Should attempt more generic steps if possible to be reusable beyond EDI where possible
 */
public class CBMStepDefs extends SpringIntegrationTest {
    static final Logger LOG = LoggerFactory.getLogger(CBMStepDefs.class);
    //public record DocID(String docType, int index) {} // Can we move this inside document ?
    static Pattern pattern = Pattern.compile("(\\w+):?(\\d+)?.?(\\w+)?");

    @Given("A random consignmentNumber with testcase number for cbm {string}, {string}")
    public void aRandomConsignmentNumberWithTestcaseNumber(String arg0, String args1) throws JAXBException {
        createARandomConsignmentNoWithDocType(args1, arg0);
    }

    /**
     * Below steps are for adding changes to the baseline document
     */
    @Then("we expect {string} document with the following cbm data")
    public void weExpectDocumentWithTheFollowingData(String arg0, DataTable dataTable) {
        List<Map<String, String>> changeFields = dataTable.asMaps(String.class, String.class);
        getDoc(arg0).getXmlFields().setChangeFields(changeFields);
    }

    @When("consumer sends a CBM message {string}")
    public void consumerSendsAEDIMessage(String arg0) throws Exception {
        String inputMsg = createMessageFromFile("input/" + arg0);
        getDocumentById(Document.CBMCONS).setBaselineDocument(inputMsg);
        final var payload = getDocumentById(Document.CBMCONS).getExpectedXMLDocument();
        LOG.info("Request processed for consignment item number : " + consignmentItemNo + " for testCaseNo " + testCaseNo);
        sendKafkaMessageToTopic("ph-oem-ord-transportorder-cbm", payload);
    }

    @Then("we expect opsconsignment document exists in cosmos database {string}")
    public void weExpectOpsconsignmentDocumentExistsInCosmosDatabase(String arg0) throws InterruptedException {
        ConsignmentItemCosmos consignmentItem = cosmosItemRepositoryService.findConsignmentItemById(arg0);
        OpsConsignment opsCons = cosmosRepositoryService.findOpsConsignmentById(consignmentItem.getConsNo());
        if (opsCons != null) {
            LOG.debug("Ops document exists in cosmos db with the consignment number as expected");
        } else {
            LOG.debug("Ops document does not exists, hence this assertion is failed");
        }
    }

    @Then("we expect consitem document exists in cosmos database {string}")
    public void weExpectConsitemDocumentExistsInCosmosDatabase(String arg0) {
        ConsignmentItemCosmos consignmentItem = cosmosItemRepositoryService.findConsignmentItemById(arg0);
        if (consignmentItem != null) {
            LOG.debug("ConsignmentItem document exists in cosmos as expected");
        } else {
            LOG.debug("ConsignmentItem document does not exists, hence this assertion is not expected");
        }
    }

    @Then("we expect service code {string} specific value {string}")
    public void weExpectServiceCodeSpecificValue(String arg0, String arg1) {
        ConsignmentItemCosmos consignmentItem = cosmosItemRepositoryService.findConsignmentItemById(arg1);
        OpsConsignment opsCons = cosmosRepositoryService.findOpsConsignmentById(consignmentItem.getConsNo());
        if (opsCons.getServiceCode().equals(arg0)) {
            LOG.debug("Expected service code exists in OpsConsignment document");
        } else {
            LOG.debug("Expected service code does not exists in OpsConsignment document");
        }
    }

    @Then("we expect synthStatusOps {string} and synthStatusItem {string} for input item {string}")
    public void weExpectSynthStatusOpsAndSynthStatusItemForInputItem(String arg0, String arg1, String arg2) {
        ConsignmentItemCosmos consignmentItem = cosmosItemRepositoryService.findConsignmentItemById(arg2);
        OpsConsignment opsCons = cosmosRepositoryService.findOpsConsignmentById(consignmentItem.getConsNo());
        if (consignmentItem.getStatus().getSyncStatus().equals(arg1)) {
            LOG.debug("Expected synthetic status matched for item");
        } else {
            LOG.debug("Expected synthetic status does not matched for item");
        }
        if (opsCons.getStatus().getSyntheticStatus().equals(arg0)) {
            LOG.debug("Expected synthetic status matched for opsConsignment document");
        } else {
            LOG.debug("Expected synthetic status does not matched for opsConsignment document");
        }
    }

    @Then("we expect vasCode {string} activeVas {string} and consVas {string} for input item {string}")
    public void weExpectVasCodeActiveVasAndConsVasForInputItem(String arg0, String arg1, String arg2, String arg3) {
        ConsignmentItemCosmos consignmentItem = cosmosItemRepositoryService.findConsignmentItemById(arg3);
        Vas vas = consignmentItem.getVas().get(0);
        if (vas.getVasCd().equals(arg0) &&
                vas.isActiveStatus() == Boolean.parseBoolean(arg1) &&
                vas.isConsVAS() == Boolean.parseBoolean(arg2)) {
            LOG.debug("Expected VasCode properties matched for item");
        } else {
            LOG.debug("Expected VasCode properties does not match for item");
        }
    }

    @Then("we expect actorNum {string} postalCode {string} consignorCntryCd {string} and consigneeCntryCd {string} for input item {string}")
    public void weExpectActorNumPostalCodeConsignorCntryCdAndConsigneeCntryCdForInputItem(String arg0, String arg1, String arg2, String arg3, String arg4) {
        ConsignmentItemCosmos consignmentItem = cosmosItemRepositoryService.findConsignmentItemById(arg4);
        OpsConsignment opsCons = cosmosRepositoryService.findOpsConsignmentById(consignmentItem.getConsNo());
        OpsConsignmentPartyConsignor opsConsignmentPartyConsignor = opsCons.getPartyConsignor();
        OpsConsignmentPartyConsignee opsConsignmentPartyConsignee = opsCons.getPartyConsignee();

        if (opsConsignmentPartyConsignor.getActorNo().equals(arg0) &&
                opsConsignmentPartyConsignor.getPostalAddress().getCountryCode().equals(arg2) &&
                opsConsignmentPartyConsignee.getPostalAddress().getPostalCode().equals(arg1) &&
                opsConsignmentPartyConsignee.getPostalAddress().getCountryCode().equals(arg3) &&
                opsConsignmentPartyConsignee.getDeliveryAddress().getPostalCode().equals(arg1) &&
                opsConsignmentPartyConsignee.getDeliveryAddress().getCountryCode().equals(arg3)) {
            LOG.debug("Expected properties for consignee and consignor matched for ops document");
        } else {
            LOG.debug("Expected properties not matched for consignee and consignor matched for ops document");
        }

    }


    /**
     * Below steps are for handling parsing of the data from the steps like multiple documents, vas, tables with datatype, error codes
     */


    public List<Document> getDocuments(String docs) {
        return getDocIDs(docs).stream().map(this::getDoc).toList();
    }

    public List<Document.DocID> getDocIDs(String docs) {
        if (docs.contains(",")) {
            return Arrays.stream(docs.split(",")).map(d -> getDocID(d)).toList();
        } else return List.of(getDocID(docs));
    }

    public static Document.DocID getDocID(String doc) {
        Matcher matcher = pattern.matcher(doc);
        matcher.find();
        int index = 0;
        if (matcher.group(2) != null) index = Integer.parseInt(matcher.group(2));
        return new Document.DocID(matcher.group(1), index, matcher.group(3));
    }

    public Document getDoc(String docIdString) {
        return getDoc(getDocID(docIdString));
    }
}

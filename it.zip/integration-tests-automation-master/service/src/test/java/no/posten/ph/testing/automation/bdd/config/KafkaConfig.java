package no.posten.ph.testing.automation.bdd.config;

import static org.apache.kafka.clients.CommonClientConfigs.SECURITY_PROTOCOL_CONFIG;
import static org.apache.kafka.common.config.SaslConfigs.SASL_JAAS_CONFIG;
import static org.apache.kafka.common.config.SaslConfigs.SASL_MECHANISM;

import java.util.HashMap;
import java.util.Map;

import com.azure.spring.data.cosmos.core.convert.ObjectMapperFactory;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

@Configuration
@Profile("bdd")
@EnableKafka
public class KafkaConfig {

    private static final String SASL_TRUSTSTORE_LOCATION = "ssl.truststore.location";
    private static final String SASL_TRUSTSTORE_PWORD = "ssl.truststore.password";

    @Value("${spring.kafka.consumer.bootstrap-servers}")
    private String bootStrapServer;

    @Value("${spring.kafka.consumer.group-id}")
    private String groupId;

    @Value("${spring.kafka.consumer.username}")
    private String username;
    @Value("${spring.kafka.consumer.password}")
    private String password;
    @Value("${spring.kafka.consumer.login-module}")
    private String loginModule;
    @Value("${spring.kafka.consumer.sasl-mechanism}")
    private String saslMechanism;
    @Value("${spring.kafka.consumer.security-protocol}")
    private String securityProtocol;
    @Value("${spring.kafka.consumer.truststore-location}")
    private String truststoreLocation;
    @Value("${spring.kafka.consumer.truststore-password}")
    private String truststorePassword;
    @Value("${spring.kafka.consumer.offset-auto-reset}")
    private String consumerOffsetAutoReset;
    @Value("${spring.kafka.consumer.client-config-id}")
    private String kafkaClientId;
    @Value("${spring.kafka.consumer.pollTimeout}")
    private Integer pollTimeout;
    @Value("${spring.kafka.consumer.max-age}")
    private int consumerMaxAgeTime;
    @Value("${spring.kafka.consumer.request-timeout}")
    private int consumerRequestTimeout;

    //Producer
    @Value("${spring.kafka.producer.acks-config}")
    private String producerAcksConfig;
    @Value("${spring.kafka.producer.linger}")
    private int producerLinger;
    @Value("${spring.kafka.producer.timeout}")
    private int producerRequestTimeout;
    @Value("${spring.kafka.producer.retries}")
    private int producerRetries;
    @Value("${spring.kafka.producer.metadata-max-idle}")
    private int producerMetadataMaxIdleTime;
    @Value("${spring.kafka.producer.metadata-max-age}")
    private int producerMetadataMaxAgeTime;
    @Value("${spring.kafka.producer.delivery-timeout}")
    private int producerDeliveryTimeout;
    @Value("${spring.kafka.producer.connections-max-idle}")
    private int producerConnectionMaxIdle;
    @Value("${spring.kafka.producer.batch-size}")
    private int producerBatchSize;
    @Value("${spring.kafka.producer.send-buffer}")
    private int producerSendBuffer;

    @Bean(name = "cosmosObjectMapper, objectMapper")
    public ObjectMapper objectMapper() {
        ObjectMapper om = ObjectMapperFactory.getObjectMapper();
        return om.setSerializationInclusion(JsonInclude.Include.NON_NULL).disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootStrapServer);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, consumerRequestTimeout);
        props.put(ConsumerConfig.METADATA_MAX_AGE_CONFIG, consumerMaxAgeTime);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, consumerOffsetAutoReset);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
        addSaslProperties(props, saslMechanism, securityProtocol, loginModule, username, password);
        addTruststoreProperties(props, truststoreLocation, truststorePassword);
        return new DefaultKafkaConsumerFactory<>(props);
    }
    public static void addSaslProperties(Map<String, Object> properties, String saslMechanism, String securityProtocol, String loginModule, String username, String password) {
        if (!StringUtils.isEmpty(username)) {
            properties.put(SECURITY_PROTOCOL_CONFIG, securityProtocol);
            properties.put(SASL_MECHANISM, saslMechanism);
            properties.put(SASL_JAAS_CONFIG, String.format("%s required username=\"%s\" password=\"%s\" ;", loginModule, username, password));
        }
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String>
    kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.getContainerProperties().setIdleBetweenPolls(250);
        factory.getContainerProperties().setPollTimeout(pollTimeout);
        return factory;
    }

    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    @Bean
    public ProducerFactory<String, String> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();

        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,bootStrapServer);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
        configProps.put(ProducerConfig.LINGER_MS_CONFIG, producerLinger);
        configProps.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, producerRequestTimeout);
        configProps.put(ProducerConfig.BATCH_SIZE_CONFIG, producerBatchSize);
        configProps.put(ProducerConfig.SEND_BUFFER_CONFIG, producerSendBuffer);
        configProps.put(ProducerConfig.ACKS_CONFIG, producerAcksConfig);
        configProps.put(ProducerConfig.CLIENT_ID_CONFIG, kafkaClientId);
        configProps.put(ProducerConfig.RETRIES_CONFIG, producerRetries);
        configProps.put(ProducerConfig.METADATA_MAX_AGE_CONFIG, producerMetadataMaxAgeTime);
        configProps.put(ProducerConfig.METADATA_MAX_IDLE_CONFIG, producerMetadataMaxIdleTime);
        configProps.put(ProducerConfig.CONNECTIONS_MAX_IDLE_MS_CONFIG,producerConnectionMaxIdle);
        configProps.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, producerDeliveryTimeout);

        addSaslProperties(configProps, saslMechanism, securityProtocol, loginModule, username, password);
        addTruststoreProperties(configProps, truststoreLocation, truststorePassword);

        return new DefaultKafkaProducerFactory<>(configProps);
    }

    /**
     * This method is used to store trust store properties.
     *
     * @param properties of type Map.
     * @param location   of type String.
     * @param password   of type String.
     */

    public static void addTruststoreProperties(Map<String, Object> properties, String location, String password) {
        if (!StringUtils.isEmpty(location)) {
            properties.put(SASL_TRUSTSTORE_LOCATION, location);
            properties.put(SASL_TRUSTSTORE_PWORD, password);
        }
    }
}

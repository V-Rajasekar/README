package no.posten.ph.testing.automation.bdd.repository;

import com.azure.spring.data.cosmos.repository.CosmosRepository;
import no.posten.ph.oem.consignmentitem.api.domain.item.ConsignmentItemCosmos;
import org.springframework.stereotype.Repository;

@Repository
public interface ConsignmentItemRepository extends CosmosRepository<ConsignmentItemCosmos, String> {

}

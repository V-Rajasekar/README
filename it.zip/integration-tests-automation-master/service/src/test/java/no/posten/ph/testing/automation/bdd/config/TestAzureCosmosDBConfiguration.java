package no.posten.ph.testing.automation.bdd.config;

import java.time.Duration;

import com.azure.core.credential.AzureKeyCredential;
import com.azure.cosmos.ConsistencyLevel;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.DirectConnectionConfig;
import com.azure.cosmos.GatewayConnectionConfig;
import com.azure.spring.data.cosmos.config.AbstractCosmosConfiguration;
import com.azure.spring.data.cosmos.config.CosmosConfig;
import com.azure.spring.data.cosmos.exception.CosmosAccessException;
import com.azure.spring.data.cosmos.repository.config.EnableCosmosRepositories;
import io.github.resilience4j.core.IntervalFunction;
import io.github.resilience4j.retry.RetryConfig;
import no.posten.ph.oem.consignment.domain.service.exception.CustomCosmosRetryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@EnableCosmosRepositories(basePackages = {"no.posten.ph.oem.consignment.domain.service.repository","no.posten.ph.testing.automation.bdd.repository"})
@Profile("bdd")
public class TestAzureCosmosDBConfiguration extends AbstractCosmosConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(TestAzureCosmosDBConfiguration.class);

    @Value("${spring.cosmos.uri}")
    private String uri;

    @Value("${spring.cosmos.key}")
    private String key;

    @Value("${spring.cosmos.database}")
    private String dbName;

    @Value("${configuration.max-retry}")
    private int maxAttempts;

    @Value("${configuration.initial-interval}")
    private int initialInterval;

    @Value("${configuration.multiplier}")
    private int multiplier;

    private AzureKeyCredential azureKeyCredential;

    @Bean
    public CosmosClientBuilder cosmosClientBuilder() {
        this.azureKeyCredential = new AzureKeyCredential(this.key);

        DirectConnectionConfig directConnectionConfig = DirectConnectionConfig.getDefaultConfig();
        directConnectionConfig.setIdleEndpointTimeout(Duration.ofMinutes(30));
        GatewayConnectionConfig gatewayConnectionConfig = GatewayConnectionConfig.getDefaultConfig();
        return new CosmosClientBuilder()
                .endpoint(this.uri)
                .key(this.key)
                .consistencyLevel(ConsistencyLevel.SESSION)
                .gatewayMode(gatewayConnectionConfig);

    }

    @Bean
    public CosmosConfig cosmosConfig() {
        DirectConnectionConfig directConnectionConfig = DirectConnectionConfig.getDefaultConfig();
        return CosmosConfig.builder()
                .enableQueryMetrics(false)
                .build();
    }


    @Override
    protected String getDatabaseName() {
        return dbName;
    }

    @Bean(name = "retryConfig")
    public RetryConfig getRetryConfig() {
        return RetryConfig.custom()
                .maxAttempts(maxAttempts)
                .intervalFunction(IntervalFunction.ofExponentialBackoff(initialInterval, multiplier))
                .retryExceptions(CustomCosmosRetryException.class)
                .ignoreExceptions(CosmosAccessException.class)
                .build();
    }

}

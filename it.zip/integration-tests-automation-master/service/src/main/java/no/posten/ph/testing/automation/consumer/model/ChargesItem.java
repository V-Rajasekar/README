package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;
import java.math.BigDecimal;
import java.util.Objects;

public class ChargesItem {

    @Digits(integer = 14, fraction = 2, message = "A0063")
    private BigDecimal netAmount = BigDecimal.ZERO;

    private String chargeType;

    private String netCurrency;

    @Digits(integer = 14, fraction = 2, message = "A0064")
    private BigDecimal grossAmount = BigDecimal.ZERO;

    private String grossCurrency;

    private String chargeCode;

    public BigDecimal getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(BigDecimal netAmount) {
        if (Objects.isNull(netAmount)) {this.netAmount = BigDecimal.ZERO;}
        else {this.netAmount = netAmount;}
    }

    public String getChargeType() {
        return chargeType;
    }

    public void setChargeType(String chargeType) {
        this.chargeType = chargeType;
    }

    public String getNetCurrency() {
        return netCurrency;
    }

    public void setNetCurrency(String netCurrency) {
        this.netCurrency = netCurrency;
    }

    public BigDecimal getGrossAmount() {
        return grossAmount;
    }

    public void setGrossAmount(BigDecimal grossAmount) {
        if (Objects.isNull(grossAmount)) {this.grossAmount = BigDecimal.ZERO;}
        else {this.grossAmount = grossAmount;}
    }

    public String getGrossCurrency() {
        return grossCurrency;
    }

    public void setGrossCurrency(String grossCurrency) {
        this.grossCurrency = grossCurrency;
    }

    public String getChargeCode() {
        return chargeCode;
    }

    public void setChargeCode(String chargeCode) {
        this.chargeCode = chargeCode;
    }
}
package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

public class CashOnDelivery {

    @DecimalMin(value = "0.0", inclusive = false, message = "E0147")
    @DecimalMax(value = "999999999999.00", inclusive = true, message = "E0168")
    @Digits(integer = 14, fraction = 2)
    private BigDecimal amount;

    private String amountCheckDigit;

    @NotBlank(message = "S0506")
    private String accountType;

    @NotBlank(message = "E0123")
    private String accountNumber;

    private String controlIdentificationNumber;

    @NotBlank(message = "S0505")
    private String amountCurrency;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getAmountCheckDigit() {
        return amountCheckDigit;
    }

    public void setAmountCheckDigit(String amountCheckDigit) {
        this.amountCheckDigit = amountCheckDigit;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getControlIdentificationNumber() {
        return controlIdentificationNumber;
    }

    public void setControlIdentificationNumber(String controlIdentificationNumber) {
        this.controlIdentificationNumber = controlIdentificationNumber;
    }

    public String getAmountCurrency() {
        return amountCurrency;
    }

    public void setAmountCurrency(String amountCurrency) {
        this.amountCurrency = amountCurrency;
    }
}
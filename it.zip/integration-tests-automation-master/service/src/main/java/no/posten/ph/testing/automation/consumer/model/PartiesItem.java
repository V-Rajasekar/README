package no.posten.ph.testing.automation.consumer.model;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

public class PartiesItem {

    private String contactMobile;

    @Valid
    private List<AddressesItem> addresses;

    @Valid
    private List<ReferencesItem> references;

    private String contactEmail;

    private String contactName;

    private String partyIdType;

    @NotBlank(message = "S0034")
    private String type;

    private String contactFunction;

    private String system;

    private String subpartyId;

    private String contactTelefax;

    private String name;

    private String partyId;

    private String contactPhone;

    private String customerNo;

    public String getContactMobile() {
        return contactMobile;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile;
    }

    public List<AddressesItem> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<AddressesItem> addresses) {
        this.addresses = addresses;
    }

    public List<ReferencesItem> getReferences() {
        return references;
    }

    public void setReferences(List<ReferencesItem> references) {
        this.references = references;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getPartyIdType() {
        return partyIdType;
    }

    public void setPartyIdType(String partyIdType) {
        this.partyIdType = partyIdType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContactFunction() {
        return contactFunction;
    }

    public void setContactFunction(String contactFunction) {
        this.contactFunction = contactFunction;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getSubpartyId() {
        return subpartyId;
    }

    public void setSubpartyId(String subpartyId) {
        this.subpartyId = subpartyId;
    }

    public String getContactTelefax() {
        return contactTelefax;
    }

    public void setContactTelefax(String contactTelefax) {
        this.contactTelefax = contactTelefax;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }
}
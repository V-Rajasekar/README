package no.posten.ph.testing.automation.consumer.model;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

public class ConsignmentItems {

    @Valid
    private Insurance insurance;

    @NotBlank(message = "E0610")
    @Size(min=7, message = "A0652")
    @Size(max=35, message = "A0650")
    private String consignmentItemNo;

    @Valid
    private List<ReferencesItem> references;

    private String packageTypeCode;

    private String consignmentItemNoOrig;

    @NotBlank(message = "S0512")
    private String consignmentItemNoType;

    @NotBlank(message = "S0513")
    private String goodsItemRef;

    @Valid
    private List<ChargesItem> charges;

    private String marking;

    @Valid
    private List<FreeTextItem> freeText;

    private String consignmentItemNoIssuer;

    private String consignmentItemNoIdentifier;

    private String goodsDescription;

    @Valid
    private ConsignmentItemsDimensions dimensions;

    public Insurance getInsurance() {
        return insurance;
    }

    public void setInsurance(Insurance insurance) {
        this.insurance = insurance;
    }

    public String getConsignmentItemNo() {
        return consignmentItemNo;
    }

    public void setConsignmentItemNo(String consignmentItemNo) {
        this.consignmentItemNo = consignmentItemNo;
    }

    public List<ReferencesItem> getReferences() {
        return references;
    }

    public void setReferences(List<ReferencesItem> references) {
        this.references = references;
    }

    public String getPackageTypeCode() {
        return packageTypeCode;
    }

    public void setPackageTypeCode(String packageTypeCode) {
        this.packageTypeCode = packageTypeCode;
    }

    public String getConsignmentItemNoOrig() {
        return consignmentItemNoOrig;
    }

    public void setConsignmentItemNoOrig(String consignmentItemNoOrig) {
        this.consignmentItemNoOrig = consignmentItemNoOrig;
    }

    public String getConsignmentItemNoType() {
        return consignmentItemNoType;
    }

    public void setConsignmentItemNoType(String consignmentItemNoType) {
        this.consignmentItemNoType = consignmentItemNoType;
    }

    public String getGoodsItemRef() {
        return goodsItemRef;
    }

    public void setGoodsItemRef(String goodsItemRef) {
        this.goodsItemRef = goodsItemRef;
    }

    public List<ChargesItem> getCharges() {
        return charges;
    }

    public void setCharges(List<ChargesItem> charges) {
        this.charges = charges;
    }

    public String getMarking() {
        return marking;
    }

    public void setMarking(String marking) {
        this.marking = marking;
    }

    public List<FreeTextItem> getFreeText() {
        return freeText;
    }

    public void setFreeText(List<FreeTextItem> freeText) {
        this.freeText = freeText;
    }

    public String getConsignmentItemNoIssuer() {
        return consignmentItemNoIssuer;
    }

    public void setConsignmentItemNoIssuer(String consignmentItemNoIssuer) {
        this.consignmentItemNoIssuer = consignmentItemNoIssuer;
    }

    public String getConsignmentItemNoIdentifier() {
        return consignmentItemNoIdentifier;
    }

    public void setConsignmentItemNoIdentifier(String consignmentItemNoIdentifier) {
        this.consignmentItemNoIdentifier = consignmentItemNoIdentifier;
    }

    public String getGoodsDescription() {
        return goodsDescription;
    }

    public void setGoodsDescription(String goodsDescription) {
        this.goodsDescription = goodsDescription;
    }

    public ConsignmentItemsDimensions getDimensions() {
        return dimensions;
    }

    public void setDimensions(ConsignmentItemsDimensions dimensions) {
        this.dimensions = dimensions;
    }
}
package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;
import java.math.BigDecimal;

public class ConsignmentItemsDimensions {

    private Integer grossVolumeCm3 = 0;

    @Digits(integer = 4, fraction = 2)
    private BigDecimal loadingMetres = BigDecimal.ZERO;

    @Digits(integer = 4, fraction = 0)
    private Integer palletFootprints = 0;

    private Integer netWeightGrams = 0;

    private Integer grossWeightGrams = 0;

    private Integer heightCm = 0;

    private Integer widthCm = 0;

    private Integer lengthCm = 0;

    public Integer getGrossVolumeCm3() {
        return grossVolumeCm3;
    }

    public void setGrossVolumeCm3(Integer grossVolumeCm3) {
        this.grossVolumeCm3 = grossVolumeCm3;
    }

    public BigDecimal getLoadingMetres() {
        return loadingMetres;
    }

    public void setLoadingMetres(BigDecimal loadingMetres) {
        this.loadingMetres = loadingMetres;
    }

    public Integer getPalletFootprints() {
        return palletFootprints;
    }

    public void setPalletFootprints(Integer palletFootprints) {
        this.palletFootprints = palletFootprints;
    }

    public Integer getNetWeightGrams() {
        return netWeightGrams;
    }

    public void setNetWeightGrams(Integer netWeightGrams) {
        this.netWeightGrams = netWeightGrams;
    }

    public Integer getGrossWeightGrams() {
        return grossWeightGrams;
    }

    public void setGrossWeightGrams(Integer grossWeightGrams) {
        this.grossWeightGrams = grossWeightGrams;
    }

    public Integer getHeightCm() {
        return heightCm;
    }

    public void setHeightCm(Integer heightCm) {
        this.heightCm = heightCm;
    }

    public Integer getWidthCm() {
        return widthCm;
    }

    public void setWidthCm(Integer widthCm) {
        this.widthCm = widthCm;
    }

    public Integer getLengthCm() {
        return lengthCm;
    }

    public void setLengthCm(Integer lengthCm) {
        this.lengthCm = lengthCm;
    }
}
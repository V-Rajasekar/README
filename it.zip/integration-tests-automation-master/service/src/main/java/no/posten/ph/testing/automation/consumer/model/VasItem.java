package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.NotBlank;

public class VasItem {

    private String discountPercent;

    private String serviceRequirements;

    @NotBlank(message = "A0030")
    private String vasCode;

    public String getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(String discountPercent) {
        this.discountPercent = discountPercent;
    }

    public String getServiceRequirements() {
        return serviceRequirements;
    }

    public void setServiceRequirements(String serviceRequirements) {
        this.serviceRequirements = serviceRequirements;
    }

    public String getVasCode() {
        return vasCode;
    }

    public void setVasCode(String vasCode) {
        this.vasCode = vasCode;
    }
}
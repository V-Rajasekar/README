package no.posten.ph.testing.automation.consumer.model;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

public class Consignment {

    @NotBlank(message = "S0504")
    private String termsCode;

    @Valid
    private Insurance insurance;

    private String orderType;

    @Valid
    private List<ReferencesItem> references;

    @NotBlank(message = "A0022")
    private String serviceCode;

    @Valid
    private List<TimestampsItem> timestamps;

    @Digits(integer = 5, fraction = 0)
    private Integer numberOfItems = 0;

    @NotBlank(message = "H0150")
    private String termsOfDelivery;

    @Valid
    private List<GoodsItem> goodsItem;

    @NotBlank(message = "S0501")
    private String consignmentNoType;

    private String discountRegisteredBy;

    @Valid
    private List<TrackingRecipientsItem> trackingRecipients;

    private String goodsDescription;

    private String consignmentNoIdentifier;

    private String termsLocation;

    @Valid
    private List<DangerousGoodsItem> dangerousGoods;

    @Valid
    private TemperatureRequirementsCelsius temperatureRequirementsCelsius;

    @Valid
    private CashOnDelivery cashOnDelivery;

    @Valid
    @NotNull(message = "F0500")
    private MsgHeader msgHeader;

    private String serviceGroup;

    @Valid
    private List<VasItem> vas;

    @NotBlank(message = "F0020")
    private String consignmentNo;

    @Valid
    private List<EquipmentItem> equipments;

    @Valid
    private List<ChargesItem> charges;

    @Digits(integer = 7, fraction = 2)
    private BigDecimal agreedDiscount = BigDecimal.ZERO;

    @Valid
    private List<FreeTextItem> freeText;

    @Valid
    private List<PartiesItem> parties;

    @Digits(integer = 9, fraction = 0)
    private Integer dangerousGoodsTotalPoints = 0;

    private String consignmentNoIssuer;

    @NotBlank(message = "S0503")
    private String termsType;

    private String consignmentMaster;

    @Valid
    private ConsignmentDimensions dimensions;

    public String getTermsCode() {
        return termsCode;
    }

    public void setTermsCode(String termsCode) {
        this.termsCode = termsCode;
    }

    public Insurance getInsurance() {
        return insurance;
    }

    public void setInsurance(Insurance insurance) {
        this.insurance = insurance;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<ReferencesItem> getReferences() {
        return references;
    }

    public void setReferences(List<ReferencesItem> references) {
        this.references = references;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public List<TimestampsItem> getTimestamps() {
        return timestamps;
    }

    public void setTimestamps(List<TimestampsItem> timestamps) {
        this.timestamps = timestamps;
    }

    public Integer getNumberOfItems() {
        return numberOfItems;
    }

    public void setNumberOfItems(Integer numberOfItems) {
        this.numberOfItems = numberOfItems;
    }

    public String getTermsOfDelivery() {
        return termsOfDelivery;
    }

    public void setTermsOfDelivery(String termsOfDelivery) {
        this.termsOfDelivery = termsOfDelivery;
    }

    public List<GoodsItem> getGoodsItem() {
        return goodsItem;
    }

    public void setGoodsItem(List<GoodsItem> goodsItem) {
        this.goodsItem = goodsItem;
    }

    public String getConsignmentNoType() {
        return consignmentNoType;
    }

    public void setConsignmentNoType(String consignmentNoType) {
        this.consignmentNoType = consignmentNoType;
    }

    public String getDiscountRegisteredBy() {
        return discountRegisteredBy;
    }

    public void setDiscountRegisteredBy(String discountRegisteredBy) {
        this.discountRegisteredBy = discountRegisteredBy;
    }

    public List<TrackingRecipientsItem> getTrackingRecipients() {
        return trackingRecipients;
    }

    public void setTrackingRecipients(List<TrackingRecipientsItem> trackingRecipients) {
        this.trackingRecipients = trackingRecipients;
    }

    public String getGoodsDescription() {
        return goodsDescription;
    }

    public void setGoodsDescription(String goodsDescription) {
        this.goodsDescription = goodsDescription;
    }

    public String getConsignmentNoIdentifier() {
        return consignmentNoIdentifier;
    }

    public void setConsignmentNoIdentifier(String consignmentNoIdentifier) {
        this.consignmentNoIdentifier = consignmentNoIdentifier;
    }

    public String getTermsLocation() {
        return termsLocation;
    }

    public void setTermsLocation(String termsLocation) {
        this.termsLocation = termsLocation;
    }

    public List<DangerousGoodsItem> getDangerousGoods() {
        return dangerousGoods;
    }

    public void setDangerousGoods(List<DangerousGoodsItem> dangerousGoods) {
        this.dangerousGoods = dangerousGoods;
    }

    public TemperatureRequirementsCelsius getTemperatureRequirementsCelsius() {
        return temperatureRequirementsCelsius;
    }

    public void setTemperatureRequirementsCelsius(TemperatureRequirementsCelsius temperatureRequirementsCelsius) {
        this.temperatureRequirementsCelsius = temperatureRequirementsCelsius;
    }

    public CashOnDelivery getCashOnDelivery() {
        return cashOnDelivery;
    }

    public void setCashOnDelivery(CashOnDelivery cashOnDelivery) {
        this.cashOnDelivery = cashOnDelivery;
    }

    public MsgHeader getMsgHeader() {
        return msgHeader;
    }

    public void setMsgHeader(MsgHeader msgHeader) {
        this.msgHeader = msgHeader;
    }

    public String getServiceGroup() {
        return serviceGroup;
    }

    public void setServiceGroup(String serviceGroup) {
        this.serviceGroup = serviceGroup;
    }

    public List<VasItem> getVas() {
        return vas;
    }

    public void setVas(List<VasItem> vas) {
        this.vas = vas;
    }

    public String getConsignmentNo() {
        return consignmentNo;
    }

    public void setConsignmentNo(String consignmentNo) {
        this.consignmentNo = consignmentNo;
    }

    public List<EquipmentItem> getEquipments() {
        return equipments;
    }

    public void setEquipments(List<EquipmentItem> equipments) {
        this.equipments = equipments;
    }

    public List<ChargesItem> getCharges() {
        return charges;
    }

    public void setCharges(List<ChargesItem> charges) {
        this.charges = charges;
    }

    public BigDecimal getAgreedDiscount() {
        return agreedDiscount;
    }

    public void setAgreedDiscount(BigDecimal agreedDiscount) {
        this.agreedDiscount = agreedDiscount;
    }

    public List<FreeTextItem> getFreeText() {
        return freeText;
    }

    public void setFreeText(List<FreeTextItem> freeText) {
        this.freeText = freeText;
    }

    public List<PartiesItem> getParties() {
        return parties;
    }

    public void setParties(List<PartiesItem> parties) {
        this.parties = parties;
    }

    public Integer getDangerousGoodsTotalPoints() {
        return dangerousGoodsTotalPoints;
    }

    public void setDangerousGoodsTotalPoints(Integer dangerousGoodsTotalPoints) {
        this.dangerousGoodsTotalPoints = dangerousGoodsTotalPoints;
    }

    public String getConsignmentNoIssuer() {
        return consignmentNoIssuer;
    }

    public void setConsignmentNoIssuer(String consignmentNoIssuer) {
        this.consignmentNoIssuer = consignmentNoIssuer;
    }

    public String getTermsType() {
        return termsType;
    }

    public void setTermsType(String termsType) {
        this.termsType = termsType;
    }

    public String getConsignmentMaster() {
        return consignmentMaster;
    }

    public void setConsignmentMaster(String consignmentMaster) {
        this.consignmentMaster = consignmentMaster;
    }

    public ConsignmentDimensions getDimensions() {
        return dimensions;
    }

    public void setDimensions(ConsignmentDimensions dimensions) {
        this.dimensions = dimensions;
    }
}
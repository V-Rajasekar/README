package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class Insurance {

    @Digits(integer = 6, fraction = 2)
    private BigDecimal insuredAmount;

    private String goodsDescription;

    @NotBlank(message = "S0510")
    private String insuredAmountCurrency;

    public BigDecimal getInsuredAmount() {
        return insuredAmount;
    }

    public void setInsuredAmount(BigDecimal insuredAmount) {
        this.insuredAmount = insuredAmount;
    }

    public String getGoodsDescription() {
        return goodsDescription;
    }

    public void setGoodsDescription(String goodsDescription) {
        this.goodsDescription = goodsDescription;
    }

    public String getInsuredAmountCurrency() {
        return insuredAmountCurrency;
    }

    public void setInsuredAmountCurrency(String insuredAmountCurrency) {
        this.insuredAmountCurrency = insuredAmountCurrency;
    }
}
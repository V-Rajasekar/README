package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.NotBlank;
import java.time.OffsetDateTime;

public class TimestampsItem {

    @NotBlank(message = "S0033")
    private String type;

    private OffsetDateTime timestamp;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public OffsetDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(OffsetDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
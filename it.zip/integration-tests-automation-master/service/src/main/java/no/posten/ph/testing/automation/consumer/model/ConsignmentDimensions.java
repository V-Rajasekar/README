package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import java.math.BigDecimal;

public class ConsignmentDimensions {

    @Max(value = 999999, message = "S0197")
    private Integer grossVolumeCm3 = 0;

    @Digits(integer = 4, fraction = 2)
    private BigDecimal loadingMetres = BigDecimal.ZERO;

    @Digits(integer = 4, fraction = 0)
    private Integer palletFootprints = 0;

    private Integer netWeightGrams = 0;

    private Integer grossWeightGrams = 0;

    public Integer getGrossVolumeCm3() {
        return grossVolumeCm3;
    }

    public void setGrossVolumeCm3(Integer grossVolumeCm3) {
        this.grossVolumeCm3 = grossVolumeCm3;
    }

    public BigDecimal getLoadingMetres() {
        return loadingMetres;
    }

    public void setLoadingMetres(BigDecimal loadingMetres) {
        this.loadingMetres = loadingMetres;
    }

    public Integer getPalletFootprints() {
        return palletFootprints;
    }

    public void setPalletFootprints(Integer palletFootprints) {
        this.palletFootprints = palletFootprints;
    }

    public Integer getNetWeightGrams() {
        return netWeightGrams;
    }

    public void setNetWeightGrams(Integer netWeightGrams) {
        this.netWeightGrams = netWeightGrams;
    }

    public Integer getGrossWeightGrams() {
        return grossWeightGrams;
    }

    public void setGrossWeightGrams(Integer grossWeightGrams) {
        this.grossWeightGrams = grossWeightGrams;
    }
}
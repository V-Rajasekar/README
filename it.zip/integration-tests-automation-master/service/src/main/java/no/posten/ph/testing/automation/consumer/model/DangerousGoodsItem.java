package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;

public class DangerousGoodsItem {

    private int netWeightGrams;

    private String hazardCode;

    private String regulationCode;

    private String packaging;

    private String techName;

    private String additionalHazardCode;

    @Digits(integer = 5, fraction = 0, message = "A0060")
    private Integer unNo;

    private String tunnelRestrictions;

    private int netVolumeCm3;

    public int getNetWeightGrams() {
        return netWeightGrams;
    }

    public void setNetWeightGrams(int netWeightGrams) {
        this.netWeightGrams = netWeightGrams;
    }

    public String getHazardCode() {
        return hazardCode;
    }

    public void setHazardCode(String hazardCode) {
        this.hazardCode = hazardCode;
    }

    public String getRegulationCode() {
        return regulationCode;
    }

    public void setRegulationCode(String regulationCode) {
        this.regulationCode = regulationCode;
    }

    public String getPackaging() {
        return packaging;
    }

    public void setPackaging(String packaging) {
        this.packaging = packaging;
    }

    public String getTechName() {
        return techName;
    }

    public void setTechName(String techName) {
        this.techName = techName;
    }

    public String getAdditionalHazardCode() {
        return additionalHazardCode;
    }

    public void setAdditionalHazardCode(String additionalHazardCode) {
        this.additionalHazardCode = additionalHazardCode;
    }

    public Integer getUnNo() {
        return unNo;
    }

    public void setUnNo(Integer unNo) {
        this.unNo = unNo;
    }

    public String getTunnelRestrictions() {
        return tunnelRestrictions;
    }

    public void setTunnelRestrictions(String tunnelRestrictions) {
        this.tunnelRestrictions = tunnelRestrictions;
    }

    public int getNetVolumeCm3() {
        return netVolumeCm3;
    }

    public void setNetVolumeCm3(int netVolumeCm3) {
        this.netVolumeCm3 = netVolumeCm3;
    }
}
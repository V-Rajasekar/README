package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;

public class MsgHeader {

    @NotBlank(message = "F0014")
    private String senderId;

    private String senderIdType;

    @NotBlank(message = "F0015")
    private String senderBroker;

    @NotBlank(message = "F0012")
    private String msgId;

    @NotBlank(message = "F0009")
    private String update;

    @NotBlank(message = "F0010")
    private String type;

    @NotBlank(message = "F0013")
    private String batchId;

    @NotBlank(message = "F0011")
    private String version;

    private String senderTMS;

    @NotNull(message = "F0016")
    private OffsetDateTime timestampOrig;

    @NotNull(message = "F0017")
    private OffsetDateTime timestamp;

    private String processRequest;

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderIdType() {
        return senderIdType;
    }

    public void setSenderIdType(String senderIdType) {
        this.senderIdType = senderIdType;
    }

    public String getSenderBroker() {
        return senderBroker;
    }

    public void setSenderBroker(String senderBroker) {
        this.senderBroker = senderBroker;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getUpdate() {
        return update;
    }

    public void setUpdate(String update) {
        this.update = update;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getSenderTMS() {
        return senderTMS;
    }

    public void setSenderTMS(String senderTMS) {
        this.senderTMS = senderTMS;
    }

    public OffsetDateTime getTimestampOrig() {
        return timestampOrig;
    }

    public void setTimestampOrig(OffsetDateTime timestampOrig) {
        this.timestampOrig = timestampOrig;
    }

    public OffsetDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(OffsetDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getProcessRequest() {
        return processRequest;
    }

    public void setProcessRequest(String processRequest) {
        this.processRequest = processRequest;
    }
}
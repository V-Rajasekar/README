package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import java.math.BigDecimal;
import java.util.Objects;

public class GoodsItemDimensions {

    @Max(value = 999999, message = "S0198")
    private int grossVolumeCm3;

    @Digits(integer = 4, fraction = 2)
    private BigDecimal loadingMetres = BigDecimal.ZERO;

    private Integer netWeightGrams = 1;

    private Integer grossWeightGrams = 1;

    public int getGrossVolumeCm3() {
        return grossVolumeCm3;
    }

    public void setGrossVolumeCm3(int grossVolumeCm3) {
        this.grossVolumeCm3 = grossVolumeCm3;
    }

    public BigDecimal getLoadingMetres() {
        return loadingMetres;
    }

    public void setLoadingMetres(BigDecimal loadingMetres) {
        if (Objects.isNull(loadingMetres)) {
            this.loadingMetres = BigDecimal.ZERO;
        } else {
            this.loadingMetres = loadingMetres;
        }
    }

    public Integer getNetWeightGrams() {
        return netWeightGrams;
    }

    public void setNetWeightGrams(Integer netWeightGrams) {
        if (Objects.isNull(netWeightGrams)) {
            this.netWeightGrams = 1;
        } else {
            this.netWeightGrams = netWeightGrams;
        }
    }

    public Integer getGrossWeightGrams() {
        return grossWeightGrams;
    }

    public void setGrossWeightGrams(Integer grossWeightGrams) {
        if (Objects.isNull(grossWeightGrams)) {
            this.grossWeightGrams = 1;
        } else {
            this.grossWeightGrams = grossWeightGrams;
        }
    }

}
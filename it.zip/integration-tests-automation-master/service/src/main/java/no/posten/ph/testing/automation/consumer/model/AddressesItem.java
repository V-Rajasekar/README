package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.NotBlank;

public class AddressesItem {

    private String geoCoordSys;

    private String washingStatus;

    private String city;

    private String postalCode;

    @NotBlank(message = "S0035")
    private String type;

    private String geoCoordX;

    private String geoCoordY;

    private String addressId;

    private String receiverId;

    private String street;

    private String countryCode;

    private String addressLine1;

    private String addressLine2;

    private String washingResultCode;

    public String getGeoCoordSys() {
        return geoCoordSys;
    }

    public void setGeoCoordSys(String geoCoordSys) {
        this.geoCoordSys = geoCoordSys;
    }

    public String getWashingStatus() {
        return washingStatus;
    }

    public void setWashingStatus(String washingStatus) {
        this.washingStatus = washingStatus;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getGeoCoordX() {
        return geoCoordX;
    }

    public void setGeoCoordX(String geoCoordX) {
        this.geoCoordX = geoCoordX;
    }

    public String getGeoCoordY() {
        return geoCoordY;
    }

    public void setGeoCoordY(String geoCoordY) {
        this.geoCoordY = geoCoordY;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getWashingResultCode() {
        return washingResultCode;
    }

    public void setWashingResultCode(String washingResultCode) {
        this.washingResultCode = washingResultCode;
    }
}
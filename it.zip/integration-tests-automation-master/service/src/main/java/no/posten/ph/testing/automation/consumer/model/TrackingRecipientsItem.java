package no.posten.ph.testing.automation.consumer.model;

public class TrackingRecipientsItem {

    private String ediId;

    private String type;

    private String customerNo;

    public String getEdiId() {
        return ediId;
    }

    public void setEdiId(String ediId) {
        this.ediId = ediId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }
}
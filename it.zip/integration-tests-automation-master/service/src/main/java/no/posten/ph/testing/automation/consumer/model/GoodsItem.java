package no.posten.ph.testing.automation.consumer.model;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import java.util.List;

public class GoodsItem {

    @NotBlank(message = "S0507")
    private String lineNumber;

    private String marking;

    @Valid
    private List<ReferencesItem> references;

    @Valid
    private List<DangerousGoodsItem> dangerousGoods;

    @Digits(integer = 5, fraction = 0)
    private int numberOfItems;

    private String packageTypeCode;

    @Valid
    private List<FreeTextItem> freeText;

    private String goodsDescription;

    @Valid
    private GoodsItemDimensions dimensions;

    @Valid
    private List<ConsignmentItems> consignmentItems;

    public List<ConsignmentItems> getConsignmentItems() {
        return consignmentItems;
    }

    public void setConsignmentItems(List<ConsignmentItems> consignmentItems) {
        this.consignmentItems = consignmentItems;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getMarking() {
        return marking;
    }

    public void setMarking(String marking) {
        this.marking = marking;
    }

    public List<ReferencesItem> getReferences() {
        return references;
    }

    public void setReferences(List<ReferencesItem> references) {
        this.references = references;
    }

    public List<DangerousGoodsItem> getDangerousGoods() {
        return dangerousGoods;
    }

    public void setDangerousGoods(List<DangerousGoodsItem> dangerousGoods) {
        this.dangerousGoods = dangerousGoods;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public void setNumberOfItems(int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }

    public String getPackageTypeCode() {
        return packageTypeCode;
    }

    public void setPackageTypeCode(String packageTypeCode) {
        this.packageTypeCode = packageTypeCode;
    }

    public List<FreeTextItem> getFreeText() {
        return freeText;
    }

    public void setFreeText(List<FreeTextItem> freeText) {
        this.freeText = freeText;
    }

    public String getGoodsDescription() {
        return goodsDescription;
    }

    public void setGoodsDescription(String goodsDescription) {
        this.goodsDescription = goodsDescription;
    }

    public GoodsItemDimensions getDimensions() {
        return dimensions;
    }

    public void setDimensions(GoodsItemDimensions dimensions) {
        this.dimensions = dimensions;
    }
}
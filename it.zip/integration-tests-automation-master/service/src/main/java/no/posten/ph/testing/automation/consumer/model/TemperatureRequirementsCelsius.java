package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;
import java.math.BigDecimal;

public class TemperatureRequirementsCelsius {

    @Digits(integer = 5, fraction = 2)
    private BigDecimal transportMin;

    @Digits(integer = 5, fraction = 2)
    private BigDecimal storageMax;

    @Digits(integer = 5, fraction = 2)
    private BigDecimal transportMax;

    @Digits(integer = 5, fraction = 2)
    private BigDecimal storageMin;

    public BigDecimal getTransportMin() {
        return transportMin;
    }

    public void setTransportMin(BigDecimal transportMin) {
        this.transportMin = transportMin;
    }

    public BigDecimal getStorageMax() {
        return storageMax;
    }

    public void setStorageMax(BigDecimal storageMax) {
        this.storageMax = storageMax;
    }

    public BigDecimal getTransportMax() {
        return transportMax;
    }

    public void setTransportMax(BigDecimal transportMax) {
        this.transportMax = transportMax;
    }

    public BigDecimal getStorageMin() {
        return storageMin;
    }

    public void setStorageMin(BigDecimal storageMin) {
        this.storageMin = storageMin;
    }
}
package no.posten.ph.testing.automation.consumer.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class EquipmentItem {

    @Digits(integer = 6, fraction = 0)
    @NotNull(message = "S0511")
    private Integer equipmentQuantity = 0;

    @NotBlank(message = "S0160")
    private String equipmentType;

    public Integer getEquipmentQuantity() {
        return equipmentQuantity;
    }

    public void setEquipmentQuantity(Integer equipmentQuantity) {
        this.equipmentQuantity = equipmentQuantity;
    }

    public String getEquipmentType() {
        return equipmentType;
    }

    public void setEquipmentType(String equipmentType) {
        this.equipmentType = equipmentType;
    }
}
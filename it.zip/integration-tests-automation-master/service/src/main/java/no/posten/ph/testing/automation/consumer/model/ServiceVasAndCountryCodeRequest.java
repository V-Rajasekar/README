package no.posten.ph.testing.automation.consumer.model;

import java.io.Serializable;
import java.util.List;

public class ServiceVasAndCountryCodeRequest implements Serializable {

    private String serviceCode;

    private String sourceCountryCode;

    private String destinationCountryCode;

    private List<String> vasCodes;

    private boolean isInsured;

    private boolean hasCashOnDelivery;

    private boolean isConsignorMobileValid;

    private boolean isConsigneeMobileValid;

    private boolean isNotifyPartyMobileValid;

    private boolean isConsignorEmailValid;

    private boolean isConsigneeEmailValid;

    private boolean isNotifyPartyEmailValid;

    private ServiceVasAndCountryCodeRequest() {

    }

    private ServiceVasAndCountryCodeRequest(Builder builder) {
        this.serviceCode = builder.serviceCode;
        this.sourceCountryCode = builder.sourceCountryCode;
        this.destinationCountryCode = builder.destinationCountryCode;
        this.vasCodes = builder.vasCodes;
        this.isInsured = builder.isInsured;
        this.hasCashOnDelivery = builder.hasCashOnDelivery;
        this.isConsignorEmailValid = builder.isConsignorEmailValid;
        this.isConsigneeEmailValid = builder.isConsigneeEmailValid;
        this.isNotifyPartyEmailValid = builder.isNotifyPartyEmailValid;
        this.isConsignorMobileValid = builder.isConsignorMobileValid;
        this.isConsigneeMobileValid = builder.isConsigneeMobileValid;
        this.isNotifyPartyMobileValid = builder.isNotifyPartyMobileValid;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public String getSourceCountryCode() {
        return sourceCountryCode;
    }

    public String getDestinationCountryCode() {
        return destinationCountryCode;
    }

    public void setVasCodes(List<String> vasCodes) {
        this.vasCodes = vasCodes;
    }

    public List<String> getVasCodes() {
        return vasCodes;
    }

    public boolean isInsured() {
        return isInsured;
    }

    public boolean isConsignorMobileValid() {
        return isConsignorMobileValid;
    }

    public boolean isConsigneeMobileValid() {
        return isConsigneeMobileValid;
    }

    public boolean isNotifyPartyMobileValid() {
        return isNotifyPartyMobileValid;
    }

    public boolean isConsignorEmailValid() {
        return isConsignorEmailValid;
    }

    public boolean isConsigneeEmailValid() {
        return isConsigneeEmailValid;
    }

    public boolean isNotifyPartyEmailValid() {
        return isNotifyPartyEmailValid;
    }

    public boolean isHasCashOnDelivery() {
        return hasCashOnDelivery;
    }

    public static class Builder {


        private String serviceCode;

        private String sourceCountryCode;

        private String destinationCountryCode;

        private List<String> vasCodes;

        private boolean isInsured;

        private boolean hasCashOnDelivery;

        private boolean isConsignorMobileValid;

        private boolean isConsigneeMobileValid;

        private boolean isNotifyPartyMobileValid;

        private boolean isConsignorEmailValid;

        private boolean isConsigneeEmailValid;

        private boolean isNotifyPartyEmailValid;

        public Builder serviceCode(String serviceCode) {
            this.serviceCode = serviceCode;
            return this;
        }

        public Builder sourceCountryCode(String sourceCountryCode) {
            this.sourceCountryCode = sourceCountryCode;
            return this;
        }

        public Builder destinationCountryCode(String destinationCountryCode) {
            this.destinationCountryCode = destinationCountryCode;
            return this;
        }

        public Builder vasCodes(List<String> vasCodes) {
            this.vasCodes = vasCodes;
            return this;
        }

        public Builder insured(boolean insured) {
            isInsured = insured;
            return this;
        }

        public Builder hasCashOnDelivery(boolean hasCashOnDelivery) {
            this.hasCashOnDelivery = hasCashOnDelivery;
            return this;
        }

        public Builder consignorMobileValid(boolean consignorMobileValid) {
            isConsignorMobileValid = consignorMobileValid;
            return this;
        }

        public Builder consigneeMobileValid(boolean consigneeMobileValid) {
            isConsigneeMobileValid = consigneeMobileValid;
            return this;
        }

        public Builder notifyPartyMobileValid(boolean notifyPartyMobileValid) {
            isNotifyPartyMobileValid = notifyPartyMobileValid;
            return this;
        }

        public Builder consignorEmailValid(boolean consignorEmailValid) {
            isConsignorEmailValid = consignorEmailValid;
            return this;
        }

        public Builder consigneeEmailValid(boolean consigneeEmailValid) {
            isConsigneeEmailValid = consigneeEmailValid;
            return this;
        }

        public Builder notifyPartyEmailValid(boolean notifyPartyEmailValid) {
            isNotifyPartyEmailValid = notifyPartyEmailValid;
            return this;
        }

        public ServiceVasAndCountryCodeRequest build() {
            return new ServiceVasAndCountryCodeRequest(this);
        }
    }

     @Override
    public String toString() {
        return "ServiceVasAndCountryCodeRequest{" +
                "serviceCode='" + serviceCode + '\'' +
                ", sourceCountryCode='" + sourceCountryCode + '\'' +
                ", destinationCountryCode='" + destinationCountryCode + '\'' +
                ", vasCodes=" + vasCodes +
                ", isInsured=" + isInsured +
                ", hasCashOnDelivery=" + hasCashOnDelivery +
                ", isConsignorMobileValid=" + isConsignorMobileValid +
                ", isConsigneeMobileValid=" + isConsigneeMobileValid +
                ", isNotifyPartyMobileValid=" + isNotifyPartyMobileValid +
                ", isConsignorEmailValid=" + isConsignorEmailValid +
                ", isConsigneeEmailValid=" + isConsigneeEmailValid +
                ", isNotifyPartyEmailValid=" + isNotifyPartyEmailValid +
                '}';
    }

}

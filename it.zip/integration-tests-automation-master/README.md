# integration-tests-automation
This Service provides automation testing for E2E testing on SIT environment
## Documents Supported -
For Kafka send step currently we only support MbEdi
Cosmos steps can use any of the 4 cosmos document types - EdiCons, OpsCons,GoodsItem,ConsItem
In case of consignment item since we can have more than 1 consignment item we need to append ConsItem with the sequence number 
e.g. ConsItem:1 indicates first consignment item in the consignment.
## Steps Supported -

### 1
```gherkin
Given A random consignmentNumber with testcase number "<testcaseno>"
```
This step is expected as the first step for each EDI Test case
This testcase no can be kept unique to it is easier to find logs for a specific test case in the action logs
A unique random consignment number is generated in this step and used throughout the scenario for substitution
1 is added to each subsequent consignment item to generate a unique consignment item number and used throughtout the scenario for substitution

### 1.1
```gherkin
Given An identifier generation type "ConsItem" create a random identifiers with testcase number "<testcaseno>"
```
This step is expected as the first step for each EDI Test case
This testcase no can be kept unique to it is easier to find logs for a specific test case in the action logs
A unique random identifier is generated based on the generation type(i.e) if the generation type is consItem then generates
a random and assign it to consItemNo otherwise to consighmentNo and it is used throughout the scenario for substitution. 

### 2.1
```gherkin
And we expect "MbEdi" document with the following data
```
This step is expected in those files where some input fields need to be modified as per the test case requirements before pushing the input EDI JSON.
The required input data is given in the below format in feature fileØ

      | fieldName           | fieldPath                                     |
      | <serviceCd>         | serviceCode                                   |
      | <customerNr>        | parties[?(@.type=='Consignor')].customerNo    |

### 2.2
```gherkin
When consumer sends a EDI message "<inputJson>"
```
This step is expected in each EDI test case to send MB Json format data to the EDI topic
There the input json with MB json format in the resources/data/input folder

### 2.3
```gherkin
When sender sends "MbConsItem" document "EdiEnricherRequest.json"
```
This step is expected in each EDI test case to send MB Json format data to the EDI topic. The EDI topic is identified 
and used to send the request to the topic based on the first given param (documentType). extend this step call to configure 
your respective topic.

There the input json with MB json format in the resources/data/input folder
### 3
```gherkin
Then "EdiCons" documents saved in cosmosDB matches "<expectedEDIConsignmentJson>"
```
This step is used to verify any Cosmos persisted document matched our expected JSON provided from the resources/data/output folder
### 4
```gherkin
Then no "EdiCons,OpsCons,GoodsItem" documents are saved to cosmosDb for consignment
```
This step is used to verify none of the mentioned Cosmos documents are persited. Multiple documents can be mentioned with comma delimited fashion    
### 5
```gherkin
And no message to send to DLT
```
This step is used to verify no message is send to DLT topic
### 6
```gherkin
And a message to send to DLT with errorCode "<errorCode>"
```
This step is used to verify if the mentioned errorCode(s) are part of the error codes pulished on the DLT topic.
Multiple error codes like E0102,H0433 can be verified by mentioning in comma delimtied fashion
### 7
```gherkin
Then a consignment is published with warningCode "<errorCode>"
```
This step is used to verify if the mentioned warningCode(s) are part of the warning codes pulished on the Consignment publish topic.
Multiple warning codes like S0132,H0433 can be verified by mentioning in comma delimtied fashion
### 8
```gherkin
Then a consignment is published does not contain warningCode "<errorCode>"
```
This step is used to verify if none of the mentioned warningCode(s) are part of the warning codes pulished on the Consignment publish topic.
Multiple warning codes like S0132,H0433 can be verified to be absent by mentioning in comma delimtied fashion
### 9
```gherkin
Then we expect "EdiCons" document with the following data
      |   fieldName                    | fieldPath                                    |
      |   <partyId>                    | partyConsignor.partyId                       |
      |   <termsCode>                  | termsCode                                    |
```
You can edit multiple fields on a baseline document before publishing / comparison using this step.
This step supports EdiCons, OpsCons,GoodsItem,ConsItem as well as MbCons
This step can use used for only verification of specific fields instead of editing fields on baseline document and then comparing
fieldPath provides the jsonPath for the fields we want to edit. For complex path you can give values like parties[?(@.type=='Consignor')].partyId with filters
and fieldName can either have value directly in the datatable or give the columns name for the examples table in scenario outline
if the fieldValue is empty then it is expected that we retain the value of the field at the path from the baseline json document.
if the fieldValue is NULL then it is expected that we nullify the value of the field at the path from the baseline json document.
Currently default datatype for the fields in string. If you want to verify numeric fields then add column "dataType" with value num in the data table
### 10
```gherkin
Then verify the "EdiCons,OpsCons" documents in Cosmos
```
This step should be used after step 9 if you want to validate only few fields and not whole documents
Multiple documents can be mentioned with comma delimited fashion
### 11
```gherkin
And Cosmos has the documents "ExistingEDIConsignment.json" ,  "ExistingOpsConsignment.json", "ExistingGoodsItem.json"
```
This step should be used after step 9 if you want to validate the whole documents after superimposing the fields mentioned in step 9.
### 12
```gherkin
Then we expect the following vas on the "EdiCons,OpsCons" documents
  | vasCd     | active    |  isConsVAS |
  | 1270      | true      |  true      |
```
This step is to verify presence of specific non-blank VAS codes and values of active and isConsVAS fields on the mentioned documents
Multiple documents can be mentioned with comma delimited fashion
### 13
```gherkin
And additional VAS with vasCode "<vasCode>" and serviceRequirements "<serviceRequirements>" and discountPercent "<discountPercent>"
```
This step is to add specific VAS codes on the baseline MbCons documents before publishing to the input topic. If multiple vas needs 
to be added then add it by comma separator.
For serviceRequirement and discountPercent 1st value is the default value.
Examples:
| testNo  | i_servCode | vasCode           | serReq         | disPer       |
| TC_09.1 | 1736       | 1046,1047,1048,1046    | Ex             | 10           |
| TC_09.1 | 1736       | 1049,1050,1051    | Ex,Ex2,Ex3     | 10,20,30     |
| TC_09.1 | 1736       | 1046              | Ex             | 10           |
### 14
```gherkin
Then verify the vases "<vasnotadded>" are not added on "EdiCons,OpsCons" documents
```
This step is to verify absence of specific VAS codes on the mentioned documents. Multiple vascodes can be mentioned in comma delimited fashion.
Multiple documents can be mentioned with comma delimited fashion
### 15
```gherkin
Then we expect the following vas on the "EDICons,OpsCons" documents on top of input vases
  | vasCd     | active    |  isConsVAS |
  | 1235      | true      |  true      |
```
This step is to verify full list of VAS on the mentioned documents match the input VAS + the vas mentioned in this step
Multiple documents can be mentioned with comma delimited fashion
### 16
```gherkin
When we add "1" consignmentItem like "InputConsignmentItem.json"
```
This step is to add "n" number of consignmentItem with same values as in the baseline JSON provided from the resources/data/input folder 

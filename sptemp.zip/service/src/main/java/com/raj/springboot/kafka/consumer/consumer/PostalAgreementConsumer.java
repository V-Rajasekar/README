package com.raj.springboot.kafka.consumer.consumer;

import jakarta.xml.bind.UnmarshalException;
import com.raj.springboot.kafka.consumer.constant.ApplicationConstants;
import com.raj.springboot.kafka.consumer.entity.PostalRegisterId;
import com.raj.springboot.kafka.consumer.jaxb.PostalAgreement;
import com.raj.springboot.kafka.consumer.service.PostalAgreementService;
import com.raj.springboot.kafka.consumer.util.JaxbMarshaller;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
@Component
public class PostalAgreementConsumer {

    private static final Logger LOG = LoggerFactory.getLogger(PostalAgreementConsumer.class);

    private PostalAgreementService PostalAgreementService;
    private  JaxbMarshaller jaxbMarshaller;

    @Autowired
    public PostalAgreementConsumer(PostalAgreementService PostalAgreementService,  JaxbMarshaller jaxbMarshaller) {
        this.PostalAgreementService = PostalAgreementService;
        this.jaxbMarshaller = jaxbMarshaller;
    }

    @KafkaListener(topics = "${spring.kafka.consumer.topic}", groupId = "${spring.kafka.consumer.group-id}", idIsGroup = false)
    public void onMessage(ConsumerRecord<String, String> message,
                          Acknowledgment acknowledgment) throws UnmarshalException {
        PostalAgreement PostalAgreement = jaxbMarshaller.unmarshall(message.value());
        String spdAgreementNo = PostalAgreement.getSPDAgreementNo();
        String farCustomerAddressId = PostalAgreement.getPartySiteID();
        PostalRegisterId agreementRegisterId = new PostalRegisterId();
        LOG.debug("Received spdAgreementNo:{}  farCustomerAddressId: {} ", spdAgreementNo,
                farCustomerAddressId);
        if (!StringUtils.isBlank(spdAgreementNo) && !StringUtils.isBlank(farCustomerAddressId)) {
            String spdaIdentifier = spdAgreementNo + "/" + farCustomerAddressId;
            LOG.debug("Received SPD postal:{} for kafka offset : {}", spdaIdentifier, message.offset());
            MDC.put(ApplicationConstants.KEY1_ID, spdAgreementNo);
            MDC.put(ApplicationConstants.KEY1_TYPE, "AgreementNr");
            MDC.put(ApplicationConstants.KEY2_ID, farCustomerAddressId);
            MDC.put(ApplicationConstants.KEY2_TYPE, "FarCustomerAddressIdentifier");
            PostalAgreementService.processServicePostalAgreement(PostalAgreement);
            LOG.info("Processed SPD postal:{}", spdaIdentifier);
        } else {
            LOG.warn("Provided invalid SPDAgreementNo and PartySiteID. Message is ignored");
        }
        acknowledgment.acknowledge();
    }
}

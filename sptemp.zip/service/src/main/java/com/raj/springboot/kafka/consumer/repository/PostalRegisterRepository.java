package com.raj.springboot.kafka.consumer.repository;

import com.raj.springboot.kafka.consumer.entity.PostalRegister;
import com.raj.springboot.kafka.consumer.entity.PostalRegisterId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PostalRegisterRepository
        extends JpaRepository<PostalRegister, PostalRegisterId> {
}

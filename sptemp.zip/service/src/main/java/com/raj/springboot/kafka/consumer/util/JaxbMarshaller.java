package com.raj.springboot.kafka.consumer.util;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.UnmarshalException;
import jakarta.xml.bind.Unmarshaller;
import com.raj.springboot.kafka.consumer.jaxb.PostalAgreement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

@Component
public class JaxbMarshaller {

    private static final Logger LOG = LoggerFactory.getLogger(JaxbMarshaller.class);

    private static JAXBContext jaxbContext;

    @Autowired
    ResourceLoader resourceLoader;

    private ThreadLocal<SchemaFactory> schemaFactoryThreadLocal = new ThreadLocal<>() {
        @Override
        protected SchemaFactory initialValue() {
            SchemaFactory schemaFactory;
            try {
                schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
                schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
                schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            } catch (SAXNotRecognizedException | SAXNotSupportedException e) {
                throw new IllegalStateException("Unable to get schemaFactory", e);
            }
            return schemaFactory;
        }
    };

    private ThreadLocal<Validator> validatorThreadLocal = new ThreadLocal<>() {
        @Override
        protected Validator initialValue() {
            try {
                InputStream inputStream = null;
                inputStream = resourceLoader
                        .getResource("classpath:xsd/PostalDetail.xsd").getInputStream();
                Source schemaSource = new StreamSource(inputStream);
                Validator
                        validator =
                        schemaFactoryThreadLocal.get().newSchema(new Source[]{schemaSource}).newValidator();
                validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
                validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
                return validator;
            } catch (IOException | SAXException e) {
                LOG.error("Unable to get the validator",e);
            }
            return null;
        }

        @Override
        public void remove() {
            schemaFactoryThreadLocal.remove();
            if (validatorThreadLocal != null) {
                validatorThreadLocal.remove();
            }
        }
    };

    static {
        try {
            jaxbContext = org.eclipse.persistence.jaxb.JAXBContextFactory
                    .createContext(new Class[]{PostalAgreement.class}, null);
        } catch (JAXBException jxb) {
            throw new IllegalStateException("Unable to create jaxBContext from root element PostalAgreement.class", jxb);
        }
    }


    public PostalAgreement unmarshall(String message) throws UnmarshalException {
        try {
            validateXSD(message);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8)),
                    StandardCharsets.UTF_8);
            Source source = new StreamSource(inputStreamReader);
            return unmarshaller.unmarshal(source, PostalAgreement.class).getValue();
        } catch (Exception exception) {
            throw new UnmarshalException("Unable to unmarshall the xml input ", exception);
        }
    }

    private void validateXSD(String message) throws SAXException {
        try {
            StringReader reader = new StringReader(message);
            Validator validator = validatorThreadLocal.get();
            if (validator == null) {
                throw new IllegalAccessException("Failed to get validator to validate the XSD");
            }
            validator.validate(new StreamSource(reader));
        } catch (Exception e) {
            throw new SAXException("Incorrect input XML. Validation against XSD failed." + e);
        }
    }
}
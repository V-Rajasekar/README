package com.raj.springboot.kafka.consumer.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "postal_register")
public class PostalRegister implements Serializable {

    @EmbeddedId
    private PostalRegisterId postalRegisterId;

    @Column(name = "postal_type_code")
    private String postalTypeCode;

    @Column(name = "description")
    private String description;

    @Column(name = "mobile_nr")
    private String mobileNr;

    @Column(name = "delivery_postal_code")
    private String deliveryPostalCode;

    @Column(name = "delivery_country_code")
    private String deliveryCountryCode;

    @Column(name = "customer_nr")
    private String customerNr;

    @Column(name = "name")
    private String name;

    @Column(name = "delivery_address_line1")
    private String deliveryAddressLine1;

    @Column(name = "delivery_address_line2")
    private String deliveryAddressLine2;

    @Column(name = "delivery_postal_area")
    private String deliveryPostalArea;

    @Column(name = "email_adr")
    private String emailAdr;

    @Column(name = "delivery_instructions")
    private String deliveryInstructions;

    @Column(name = "active_status")
    private String activeStatus;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "week_nr")
    private String weekNr;

    @Column(name = "created_by_pgm")
    private String createdByPgm;

    @Column(name = "created_by_user")
    private String createdByUser;

    @Column(name = "created_by_company_code")
    private String createdByCompanyCode;

    @Column(name = "created_timestamp_db")
    private OffsetDateTime createdTimestampDb = OffsetDateTime.now();//defaults to current timestamp. better inserted via default value in sql

    @Column(name = "updated_by_pgm")
    private String updatedByPgm;

    @Column(name = "updated_by_user")
    private String updatedByUser;

    @Column(name = "updated_by_company_code")
    private String updatedByCompanyCode;

    @Column(name = "updated_timestamp")
    private OffsetDateTime updatedTimestamp;

    public PostalRegisterId getPostalRegisterId() {
        return postalRegisterId;
    }

    public void setPostalRegisterId(PostalRegisterId postalRegisterId) {
        this.postalRegisterId = postalRegisterId;
    }

    public String getPostalTypeCode() {
        return postalTypeCode;
    }

    public void setPostalTypeCode(String postalTypeCode) {
        this.postalTypeCode = postalTypeCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMobileNr() {
        return mobileNr;
    }

    public void setMobileNr(String mobileNr) {
        this.mobileNr = mobileNr;
    }

    public String getDeliveryPostalCode() {
        return deliveryPostalCode;
    }

    public void setDeliveryPostalCode(String deliveryPostalCode) {
        this.deliveryPostalCode = deliveryPostalCode;
    }

    public String getDeliveryCountryCode() {
        return deliveryCountryCode;
    }

    public void setDeliveryCountryCode(String deliveryCountryCode) {
        this.deliveryCountryCode = deliveryCountryCode;
    }

    public String getCustomerNr() {
        return customerNr;
    }

    public void setCustomerNr(String customerNr) {
        this.customerNr = customerNr;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeliveryAddressLine1() {
        return deliveryAddressLine1;
    }

    public void setDeliveryAddressLine1(String deliveryAddressLine1) {
        this.deliveryAddressLine1 = deliveryAddressLine1;
    }

    public String getDeliveryAddressLine2() {
        return deliveryAddressLine2;
    }

    public void setDeliveryAddressLine2(String deliveryAddressLine2) {
        this.deliveryAddressLine2 = deliveryAddressLine2;
    }

    public String getDeliveryPostalArea() {
        return deliveryPostalArea;
    }

    public void setDeliveryPostalArea(String deliveryPostalArea) {
        this.deliveryPostalArea = deliveryPostalArea;
    }

    public String getEmailAdr() {
        return emailAdr;
    }

    public void setEmailAdr(String emailAdr) {
        this.emailAdr = emailAdr;
    }

    public String getDeliveryInstructions() {
        return deliveryInstructions;
    }

    public void setDeliveryInstructions(String deliveryInstructions) {
        this.deliveryInstructions = deliveryInstructions;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getWeekNr() {
        return weekNr;
    }

    public void setWeekNr(String weekNr) {
        this.weekNr = weekNr;
    }

    public String getCreatedByPgm() {
        return createdByPgm;
    }

    public void setCreatedByPgm(String createdByPgm) {
        this.createdByPgm = createdByPgm;
    }

    public String getCreatedByUser() {
        return createdByUser;
    }

    public void setCreatedByUser(String createdByUser) {
        this.createdByUser = createdByUser;
    }

    public String getCreatedByCompanyCode() {
        return createdByCompanyCode;
    }

    public void setCreatedByCompanyCode(String createdByCompanyCode) {
        this.createdByCompanyCode = createdByCompanyCode;
    }

    public OffsetDateTime getCreatedTimestampDb() {
        return createdTimestampDb;
    }

    public void setCreatedTimestampDb(OffsetDateTime createdTimestampDb) {
        this.createdTimestampDb = createdTimestampDb;
    }

    public String getUpdatedByPgm() {
        return updatedByPgm;
    }

    public void setUpdatedByPgm(String updatedByPgm) {
        this.updatedByPgm = updatedByPgm;
    }

    public String getUpdatedByUser() {
        return updatedByUser;
    }

    public void setUpdatedByUser(String updatedByUser) {
        this.updatedByUser = updatedByUser;
    }

    public String getUpdatedByCompanyCode() {
        return updatedByCompanyCode;
    }

    public void setUpdatedByCompanyCode(String updatedByCompanyCode) {
        this.updatedByCompanyCode = updatedByCompanyCode;
    }

    public OffsetDateTime getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    public void setUpdatedTimestamp(OffsetDateTime updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }
}

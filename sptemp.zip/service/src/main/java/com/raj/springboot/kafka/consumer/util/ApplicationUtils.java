package com.raj.springboot.kafka.consumer.util;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;

public class ApplicationUtils {

    private ApplicationUtils() {
        //Empty constructor
    }

    /**
     * Method returning Oslo current date
     * @return returns Europe/Oslo current date
     */
    public static LocalDate getCurrentDate() {
        return OffsetDateTime.now(ZoneId.of("Europe/Oslo")).toLocalDate();
    }

}

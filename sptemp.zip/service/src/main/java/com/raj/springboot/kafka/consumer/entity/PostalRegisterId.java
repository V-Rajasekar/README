package com.raj.springboot.kafka.consumer.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.io.Serializable;

@Embeddable
public class PostalRegisterId implements Serializable {

    @Column( name = "agreement_nr")
    private String agreementNr;

    @Column(name="far_customer_address_identifier")
    private String farCustomerAddressIdentifier;

    public PostalRegisterId() {

    }
    public PostalRegisterId(String agreementNr, String farCustomerAddressIdentifier) {
        this.agreementNr = agreementNr;
        this.farCustomerAddressIdentifier = farCustomerAddressIdentifier;
    }

    public String getAgreementNr() {
        return agreementNr;
    }

    public void setAgreementNr(String agreementNr) {
        this.agreementNr = agreementNr;
    }

    public String getFarCustomerAddressIdentifier() {
        return farCustomerAddressIdentifier;
    }

    public void setFarCustomerAddressIdentifier(String farCustomerAddressIdentifier) {
        this.farCustomerAddressIdentifier = farCustomerAddressIdentifier;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        PostalRegisterId that = (PostalRegisterId) o;

        return new EqualsBuilder().append(agreementNr, that.agreementNr)
                .append(farCustomerAddressIdentifier, that.farCustomerAddressIdentifier).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(agreementNr).append(farCustomerAddressIdentifier).toHashCode();
    }

    @Override
    public String toString() {
        return "AgreementRegisterId{" +
                "agreementNr='" + agreementNr + '\'' +
                ", farCustomerAddressIdentifier='" + farCustomerAddressIdentifier + '\'' +
                '}';
    }
}

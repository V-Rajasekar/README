package com.raj.springboot.kafka.consumer.translator;

import com.raj.springboot.kafka.consumer.config.PostalAgreementProperties;
import com.raj.springboot.kafka.consumer.constant.ApplicationConstants;
import com.raj.springboot.kafka.consumer.entity.PostalRegister;
import com.raj.springboot.kafka.consumer.entity.PostalRegisterId;
import com.raj.springboot.kafka.consumer.jaxb.PostalAgreement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Objects;

@Component
public class PublishPODToPostalRegister {

    private PostalAgreementProperties PostalAgreementProperties;

    @Autowired
    public PublishPODToPostalRegister(PostalAgreementProperties PostalAgreementProperties) {
        this.PostalAgreementProperties = PostalAgreementProperties;
    }

    public PostalRegister translatePublishPODToAgreementRegister(PostalAgreement input) {
        PostalRegister postalRegister = new PostalRegister();
        createAgreementRegisterId(input, postalRegister);
        String description = input.getDescription();
        if (description != null) {
            postalRegister.setDescription(description);
        }
        translateMobileNumber(input, postalRegister);

        String partyNumber = input.getPartyNumber();
        if (partyNumber != null) {
            postalRegister.setCustomerNr(partyNumber);
        }
        String partyName = input.getPartyName();
        if (partyName != null) {
            postalRegister.setName(partyName);
        }

        createPostalAddress(input, postalRegister);
        String emailAddress = input.getEmailAddress();
        if (emailAddress != null) {
            postalRegister.setEmailAdr(emailAddress);
        }
        String deliveryInstruction = input.getDeliveryInstruction();
        if (deliveryInstruction != null) {
            postalRegister.setDeliveryInstructions(deliveryInstruction);
        }
        String status = input.getStatus();
        if (status != null) {
            postalRegister.setActiveStatus(status);
        }
        String participantStartDate = input.getParticipantStartDate();
        if (participantStartDate != null) {
            postalRegister.setStartDate(LocalDate.parse(participantStartDate));
        }
        String participantEndDate = input.getParticipantEndDate();
        if (participantEndDate != null) {
            postalRegister.setEndDate(LocalDate.parse(participantEndDate));
        }
        translateRecordHistoryDetails(postalRegister);
        return postalRegister;
    }

    private void createPostalAddress(PostalAgreement input, PostalRegister postalRegister) {
        String postalcode = input.getPostalcode();
        if (postalcode != null) {
            postalRegister.setDeliveryPostalCode(postalcode);
        }
        String city = input.getCity();
        if (city != null) {
            postalRegister.setDeliveryPostalArea(city);
        }
        String countrycode = input.getCountrycode();
        if (countrycode != null) {
            postalRegister.setDeliveryCountryCode(countrycode);
        }

        String address1 = input.getAddress1();
        if (address1 != null) {
            postalRegister.setDeliveryAddressLine1(address1);
        }
        String address2 = input.getAddress2();
        if (address2 != null) {
            postalRegister.setDeliveryAddressLine2(address2);
        }
    }

    private void createAgreementRegisterId(PostalAgreement input, PostalRegister postalRegister) {
        postalRegister.setPostalRegisterId(new PostalRegisterId(input.getSPDAgreementNo(),
                input.getPartySiteID()));

        String spdCategory = input.getSPDCategory();
        if (spdCategory != null) {
            postalRegister.setPostalTypeCode(spdCategory);
        }
    }

    private void translateMobileNumber(PostalAgreement input, PostalRegister postalRegister) {
        String phoneDetail = input.getPhoneDetail();
        if (Objects.isNull(phoneDetail)) {
            postalRegister.setMobileNr(StringUtils.EMPTY);
        } else if (!StringUtils.isBlank(phoneDetail)  && phoneDetail.startsWith(ApplicationConstants.NORGE_PHONE_PREFIX)) {
            postalRegister.setMobileNr(ApplicationConstants.PHONE_NUMBER_PREFIX + phoneDetail);
        } else {
            postalRegister.setMobileNr(phoneDetail);
        }
    }

    private void translateRecordHistoryDetails(PostalRegister postalRegister) {
        String userName = PostalAgreementProperties.getUserName();
        String companyCode = PostalAgreementProperties.getCompanyCode();
        String programName = PostalAgreementProperties.getProgramName();

        if (userName  != null) {
            postalRegister.setUpdatedByUser(userName);
        }
        if (companyCode  != null) {
            postalRegister.setUpdatedByCompanyCode(companyCode);
        }
        if (programName  != null) {
            postalRegister.setUpdatedByPgm(programName);
        }

        postalRegister.setUpdatedTimestamp(OffsetDateTime.now());

    }

    public void translateCreateRecordHistoryDetails(PostalRegister postalRegister) {
        String userName = PostalAgreementProperties.getUserName();
        String companyCode = PostalAgreementProperties.getCompanyCode();
        String programName = PostalAgreementProperties.getProgramName();
        if (userName != null) {
            postalRegister.setCreatedByUser(userName);
        }
        if (companyCode != null) {
            postalRegister.setCreatedByCompanyCode(companyCode);
        }
        if (programName != null) {
            postalRegister.setCreatedByPgm(programName);
        }
    }
}

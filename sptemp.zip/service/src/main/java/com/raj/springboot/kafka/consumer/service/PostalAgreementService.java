package com.raj.springboot.kafka.consumer.service;

import com.raj.springboot.kafka.consumer.entity.PostalRegister;
import com.raj.springboot.kafka.consumer.entity.PostalRegisterId;
import com.raj.springboot.kafka.consumer.jaxb.PostalAgreement;
import com.raj.springboot.kafka.consumer.jaxb.PostalAgreement;
import com.raj.springboot.kafka.consumer.repository.PostalRegisterRepository;
import com.raj.springboot.kafka.consumer.translator.PublishPODToPostalRegister;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.temporal.WeekFields;
import java.util.Optional;

import static com.raj.springboot.kafka.consumer.util.ApplicationUtils.getCurrentDate;

@Component
public class PostalAgreementService {

    private static final Logger LOG = LoggerFactory.getLogger(PostalAgreementService.class);

    private final PublishPODToPostalRegister podToAgreementRegisterTranslator;

    private final PostalRegisterRepository PostalRegisterRepository;

    @Autowired
    public PostalAgreementService(PublishPODToPostalRegister podToAgreementRegisterTranslator,
                                    PostalRegisterRepository PostalRegisterRepository) {
        this.podToAgreementRegisterTranslator = podToAgreementRegisterTranslator;
        this.PostalRegisterRepository = PostalRegisterRepository;
    }

    public void processServicePostalAgreement(PostalAgreement input) {
        PostalRegister postalRegister = podToAgreementRegisterTranslator
                .translatePublishPODToAgreementRegister(input);
        PostalRegisterId agreementRegisterId = postalRegister.getPostalRegisterId();
        Optional<PostalRegister> optionalOldAgreementRegister = PostalRegisterRepository
                .findById(agreementRegisterId);

            if (optionalOldAgreementRegister.isPresent()) {
                PostalRegister oldAgreementRegister = optionalOldAgreementRegister.get();
                postalRegister = updateAgreementRegister(oldAgreementRegister, postalRegister);
                LOG.debug("Update delivery postal/{}", agreementRegisterId);
            } else {
                LOG.debug("Create delivery postal/{}", agreementRegisterId);
                String currentWeekNumber = String.valueOf(getCurrentDate().get(WeekFields.ISO.weekOfYear()));
                postalRegister.setWeekNr(currentWeekNumber);
                podToAgreementRegisterTranslator.translateCreateRecordHistoryDetails(postalRegister);
            }

        PostalRegisterRepository.saveAndFlush(postalRegister);
        LOG.debug("Delivery postal/{} - Saved", agreementRegisterId);
    }

    private PostalRegister updateAgreementRegister(PostalRegister oldAgreementRegister, PostalRegister
                                                      newAgreementRegister) {
        String agreementTypeCode = newAgreementRegister.getPostalTypeCode();
        if (!StringUtils.isBlank(agreementTypeCode)) {
            oldAgreementRegister.setPostalTypeCode(agreementTypeCode);
        }
        String activeStatus = newAgreementRegister.getActiveStatus();
        if (!StringUtils.isBlank(activeStatus)) {
            oldAgreementRegister.setActiveStatus(activeStatus);
        }
        String description = newAgreementRegister.getDescription();
        if (!StringUtils.isBlank(description)) {
            oldAgreementRegister.setDescription(description);
        }
        String customerNr = newAgreementRegister.getCustomerNr();
        if (!StringUtils.isBlank(customerNr)) {
            oldAgreementRegister.setCustomerNr(customerNr);
        }
        String deliveryPostalArea = newAgreementRegister.getDeliveryPostalArea();
        if (!StringUtils.isBlank(deliveryPostalArea)) {
            oldAgreementRegister.setDeliveryPostalArea(deliveryPostalArea);
        }
        String deliveryAddressLine1 = newAgreementRegister.getDeliveryAddressLine1();
        if (!StringUtils.isBlank(deliveryAddressLine1)) {
            oldAgreementRegister.setDeliveryAddressLine1(deliveryAddressLine1);
        }
        String deliveryAddressLine2 = newAgreementRegister.getDeliveryAddressLine2();
        if (!StringUtils.isBlank(deliveryAddressLine2)) {
            oldAgreementRegister.setDeliveryAddressLine2(deliveryAddressLine2);
        }
        String deliveryCountryCode = newAgreementRegister.getDeliveryCountryCode();
        if (!StringUtils.isBlank(deliveryCountryCode)) {
            oldAgreementRegister.setDeliveryCountryCode(deliveryCountryCode);
        }
        String deliveryInstructions = newAgreementRegister.getDeliveryInstructions();
        if (!StringUtils.isBlank(deliveryInstructions)) {
            oldAgreementRegister.setDeliveryInstructions(deliveryInstructions);
        }
        String deliveryPostalCode = newAgreementRegister.getDeliveryPostalCode();
        if (!StringUtils.isBlank(deliveryPostalCode)) {
            oldAgreementRegister.setDeliveryPostalCode(deliveryPostalCode);
        }
        String emailAdr = newAgreementRegister.getEmailAdr();
        if (!StringUtils.isBlank(emailAdr)) {
            emailAdr = emailAdr.trim();
            oldAgreementRegister.setEmailAdr(emailAdr);
        }
        LocalDate startDate = newAgreementRegister.getStartDate();
        if (startDate != null) {
            oldAgreementRegister.setStartDate(startDate);
        }
        LocalDate endDate = newAgreementRegister.getEndDate();
        if (endDate != null) {
            oldAgreementRegister.setEndDate(endDate);
        }
        String mobileNr = newAgreementRegister.getMobileNr();
        if (!StringUtils.isBlank(mobileNr)) {
            oldAgreementRegister.setMobileNr(mobileNr);
        }
        String name = newAgreementRegister.getName();
        if (!StringUtils.isBlank(name)) {
            oldAgreementRegister.setName(name);
        }
        updateAgreementRecordAuditInfo(oldAgreementRegister, newAgreementRegister, startDate);
        return oldAgreementRegister;
    }

    private void updateAgreementRecordAuditInfo(PostalRegister oldAgreementRegister,
                                                PostalRegister newAgreementRegister, LocalDate startDate) {
        String updatedByPgm = newAgreementRegister.getUpdatedByPgm();
        if (!StringUtils.isBlank(updatedByPgm)) {
            oldAgreementRegister.setUpdatedByPgm(updatedByPgm);
        }
        String updatedByUser = newAgreementRegister.getUpdatedByUser();
        if (!StringUtils.isBlank(updatedByUser)) {
            oldAgreementRegister.setUpdatedByUser(updatedByUser);
        }
        String updatedByCompanyCode = newAgreementRegister.getUpdatedByCompanyCode();
        if (!StringUtils.isBlank(updatedByCompanyCode)) {
            oldAgreementRegister.setUpdatedByCompanyCode(updatedByCompanyCode);
        }
        OffsetDateTime updatedTimestamp = newAgreementRegister.getUpdatedTimestamp();
        if (startDate != null) {
            oldAgreementRegister.setUpdatedTimestamp(updatedTimestamp);
        }
    }

}

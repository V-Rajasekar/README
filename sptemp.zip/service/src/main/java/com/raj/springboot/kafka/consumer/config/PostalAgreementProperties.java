package com.raj.springboot.kafka.consumer.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("delivery-postal")
public class PostalAgreementProperties {

    private String programName;

    private String userName;

    private String companyCode;

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
}

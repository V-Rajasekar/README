package com.raj.springboot.kafka.consumer.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Headers;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class MDMDeadletterConsumer {

    private Headers kafkaMessageHeaders;

    @KafkaListener(topics="${spring.kafka.producer.deadlettertopic}")
    public void onMessage(ConsumerRecord<?, ?> consumerRecord) {
        this.kafkaMessageHeaders = consumerRecord.headers();
    }

    public Headers getKafkaMessageHeaders() {
        return kafkaMessageHeaders;
    }
}

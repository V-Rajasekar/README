package com.raj.springboot.kafka.consumer.consumer;

import static com.raj.springboot.kafka.consumer.util.ApplicationUtils.getCurrentDate;
import static java.time.Instant.ofEpochMilli;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.time.temporal.WeekFields;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import com.raj.springboot.kafka.consumer.constant.ApplicationConstants;
import com.raj.springboot.kafka.consumer.entity.PostalRegister;
import com.raj.springboot.kafka.consumer.entity.PostalRegisterId;
import com.raj.springboot.kafka.consumer.jaxb.PostalAgreement;
import com.raj.springboot.kafka.consumer.service.PostalAgreementService;
import com.raj.springboot.kafka.consumer.translator.PublishPODToPostalRegister;
import com.raj.springboot.kafka.consumer.util.JaxbMarshaller;
import jakarta.xml.bind.UnmarshalException;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Headers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.ContainerTestUtils;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;

@SpringBootTest
@EmbeddedKafka(partitions = 1)
@TestMethodOrder(MethodOrderer.MethodName.class)
@TestPropertySource(properties = {"spring.kafka.producer.bootstrap-servers=${spring.embedded.kafka.brokers}"
        , "spring.kafka.consumer.bootstrap-servers=${spring.embedded.kafka.brokers}"})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@Sql({"/schema.sql","/data.sql"})
public class PostalAgreementConsumerTest {

    @Autowired
    EmbeddedKafkaBroker embeddedKafkaBroker;

    @Autowired
    KafkaListenerEndpointRegistry endpointRegistry;

    @Value("${spring.kafka.consumer.topic}")
    private String topicName;

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    ResourceLoader resourceLoader;

    @Autowired
    PostalAgreementService PostalAgreementService;

    @Autowired
    PublishPODToPostalRegister publishPODToPostalRegister;

    @SpyBean
    private MDMDeadletterConsumer deadLetterConsumer;

    @Autowired
    JaxbMarshaller marshaller;

    @Autowired
    JdbcTemplate jdbcTemplate;

    private final String AGREEMENT_NO = "9016803";

    private final String FAR_CUSTOMER_ADDRESSID = "4678";


    @BeforeEach
    void setUp() {
        for (MessageListenerContainer messageListenerContainer : endpointRegistry.getListenerContainers()) {
            ContainerTestUtils.waitForAssignment(messageListenerContainer,
                    embeddedKafkaBroker.getPartitionsPerTopic());
        }
    }

    @Test
    public void testPostalAgreementRequestConversion() throws UnmarshalException, IOException {
            String PostalAgreementEventStr = loadPostalAgreementEvent("postal-agreement.xml");
            PostalAgreement PostalAgreement = marshaller.unmarshall(PostalAgreementEventStr);
            assertThat(PostalAgreement.getSPDAgreementNo(), equalTo("9016803"));
    }

    @Test
    public void testCreatePostalAgreementSaved() {
        try {
            String PostalAgreementEventStr = loadPostalAgreementEvent("postal-agreement.xml");
            PostalAgreement PostalAgreement = marshaller.unmarshall(PostalAgreementEventStr);
            PostalRegister expectedAgreementReg = publishPODToPostalRegister.translatePublishPODToAgreementRegister(PostalAgreement);
            publishPODToPostalRegister.translateCreateRecordHistoryDetails(expectedAgreementReg);
            expectedAgreementReg.setWeekNr(String.valueOf(getCurrentDate().get(WeekFields.ISO.weekOfYear())));
            SendResult<String, String> eventPublishedResult = kafkaTemplate
                    .send(topicName, PostalAgreementEventStr).get();
            await();
            PostalRegister PostalRegister = getPostalRegister(AGREEMENT_NO, FAR_CUSTOMER_ADDRESSID);
            PostalRegisterId PostalRegisterId = PostalRegister.getPostalRegisterId();

            createPostalAgreementFieldsCheck(PostalRegister,PostalRegisterId,expectedAgreementReg);

            assertThat(PostalRegister.getCreatedByPgm(),equalTo(expectedAgreementReg.getCreatedByPgm()));
            assertThat(PostalRegister.getCreatedByUser(),equalTo(expectedAgreementReg.getCreatedByUser()));
            assertThat(PostalRegister.getCreatedByCompanyCode(),equalTo(expectedAgreementReg.getCreatedByCompanyCode()));
            assertThat(PostalRegister.getCreatedTimestampDb().truncatedTo(ChronoUnit.HOURS),
                    equalTo(expectedAgreementReg.getCreatedTimestampDb().truncatedTo(ChronoUnit.HOURS)));
            assertThat(PostalRegister.getUpdatedByPgm(),equalTo(expectedAgreementReg.getUpdatedByPgm()));
            assertThat(PostalRegister.getUpdatedByUser(),equalTo(expectedAgreementReg.getUpdatedByUser()));
            assertThat(PostalRegister.getUpdatedByCompanyCode(),equalTo(expectedAgreementReg.getUpdatedByCompanyCode()));
            assertThat(PostalRegister.getUpdatedTimestamp().truncatedTo(ChronoUnit.HOURS),
                    equalTo(expectedAgreementReg.getUpdatedTimestamp().truncatedTo(ChronoUnit.HOURS)));


        } catch (Exception e) {
           fail("Expected not to fail", e);
        }
    }
    @Test
    public void testUpdatePostalAgreementSaved() {
        try {
            String PostalAgreementEventStr = loadPostalAgreementEvent("postal-agreement-update.xml");
            PostalAgreement  PostalAgreement = marshaller.unmarshall(PostalAgreementEventStr);
            PostalRegister expectedAgreementReg = publishPODToPostalRegister.translatePublishPODToAgreementRegister(PostalAgreement);
            publishPODToPostalRegister.translateCreateRecordHistoryDetails(expectedAgreementReg);
            SendResult<String, String> eventPublishedResult = kafkaTemplate
                    .send(topicName, PostalAgreementEventStr).get();
            await();
            PostalRegister PostalRegister = getPostalRegister(AGREEMENT_NO, FAR_CUSTOMER_ADDRESSID);
            PostalRegisterId PostalRegisterId = PostalRegister.getPostalRegisterId();

            createPostalAgreementFieldsCheck(PostalRegister,PostalRegisterId,expectedAgreementReg);

            assertThat(PostalRegister.getCreatedByPgm(),equalTo(expectedAgreementReg.getCreatedByPgm()));
            assertThat(PostalRegister.getCreatedByUser(),equalTo(expectedAgreementReg.getCreatedByUser()));
            assertThat(PostalRegister.getCreatedByCompanyCode(),equalTo(expectedAgreementReg.getCreatedByCompanyCode()));
            assertThat(PostalRegister.getCreatedTimestampDb().truncatedTo(ChronoUnit.HOURS),
                    equalTo(expectedAgreementReg.getCreatedTimestampDb().truncatedTo(ChronoUnit.HOURS)));
            assertThat(PostalRegister.getUpdatedByPgm(),equalTo(expectedAgreementReg.getUpdatedByPgm()));
            assertThat(PostalRegister.getUpdatedByUser(),equalTo(expectedAgreementReg.getUpdatedByUser()));
            assertThat(PostalRegister.getUpdatedByCompanyCode(),equalTo(expectedAgreementReg.getUpdatedByCompanyCode()));
            assertThat(PostalRegister.getUpdatedTimestamp().truncatedTo(ChronoUnit.HOURS),
                    equalTo(expectedAgreementReg.getUpdatedTimestamp().truncatedTo(ChronoUnit.HOURS)));

        } catch (Exception e) {
            fail("Expected not to fail", e);
        }
    }

    @Test
    public void testCustomerRegister_InvalidInputExceptionHandling() {
        try {
            String customerRegisterEvent = loadPostalAgreementEvent("postal-agreement-invalid-data.xml");
            SendResult<String, String> stringStringSendResult = kafkaTemplate.send(topicName, customerRegisterEvent).get();
            await();
            verifyCustomerRegisteredMessageInDeadLetterQueue(ApplicationConstants.DLT_EXCEPTION_TYPE_RETRYABLE);
        } catch (Exception e) {
            fail("Suppose to not fail", e);
        }
    }

    @Test
    public void testCustomerRegister_validateXML_with_XSD() {
        try {
            String customerRegisterEvent = loadPostalAgreementEvent("postal-agreement-xsd-validation.xml");
            SendResult<String, String> stringStringSendResult = kafkaTemplate.send(topicName, customerRegisterEvent).get();
            await();
            verify(deadLetterConsumer, atMostOnce()).onMessage(isA(ConsumerRecord.class));
        } catch (Exception e) {
            fail("Suppose to not fail", e);
        }
    }

    private String loadPostalAgreementEvent(String fileName) throws IOException {
        File resource = resourceLoader
                .getResource("classpath:data/" + fileName).getFile();
        return new String(
                Files.readAllBytes(resource.toPath()));
    }

    private void await() throws InterruptedException {
        CountDownLatch countDownLatch = new CountDownLatch(1);
        countDownLatch.await(4, TimeUnit.SECONDS);
    }
    private PostalRegister getPostalRegister(String agreement_nr, String farCustomerAddressId) {
        return jdbcTemplate.queryForObject("SELECT * FROM postal_register WHERE agreement_nr=? " +
                        "and far_customer_address_identifier=?", new Object[] {agreement_nr, farCustomerAddressId},  ((rs, rowNum) -> {
            PostalRegister postalReg = new PostalRegister();
            PostalRegisterId PostalRegisterId = new PostalRegisterId();
            PostalRegisterId.setAgreementNr(rs.getString("agreement_nr"));
            PostalRegisterId.setFarCustomerAddressIdentifier(rs.getString("far_customer_address_identifier"));
            postalReg.setPostalRegisterId(PostalRegisterId);
            postalReg.setPostalTypeCode(rs.getString("postal_type_code"));
            postalReg.setDescription(rs.getString("description"));
            postalReg.setMobileNr(rs.getString("mobile_nr"));
            postalReg.setDeliveryPostalCode(rs.getString("delivery_postal_code"));
            postalReg.setDeliveryCountryCode(rs.getString("delivery_country_code"));
            postalReg.setCustomerNr(rs.getString("customer_nr"));
            postalReg.setName(rs.getString("name"));
            postalReg.setDeliveryAddressLine1(rs.getString("delivery_address_line1"));
            postalReg.setDeliveryAddressLine2(rs.getString("delivery_address_line2"));
            postalReg.setDeliveryPostalArea(rs.getString("delivery_postal_area"));
            postalReg.setEmailAdr(rs.getString("email_adr"));
            postalReg.setDeliveryInstructions(rs.getString("delivery_instructions"));
            postalReg.setActiveStatus(rs.getString("active_status"));
            postalReg.setStartDate(rs.getDate("start_date").toLocalDate());
            postalReg.setEndDate(rs.getDate("end_date").toLocalDate());
            postalReg.setWeekNr(rs.getString("week_nr"));
            postalReg.setCreatedByPgm(rs.getString("created_by_pgm"));
            postalReg.setCreatedByUser(rs.getString("created_by_user"));
            postalReg.setCreatedByCompanyCode(rs.getString("created_by_company_code"));
            postalReg.setCreatedTimestampDb( OffsetDateTime.ofInstant(
                    ofEpochMilli(rs.getTimestamp("created_timestamp_db").getTime()), ZoneId.systemDefault()));
            postalReg.setUpdatedByPgm(rs.getString("updated_by_pgm"));
            postalReg.setUpdatedByUser(rs.getString("updated_by_user"));
            postalReg.setUpdatedByCompanyCode(rs.getString("updated_by_company_code"));
            postalReg.setUpdatedTimestamp( OffsetDateTime.ofInstant(
                    ofEpochMilli(rs.getTimestamp("updated_timestamp").getTime()), ZoneId.systemDefault()));
            return postalReg;
        }));
    }

    private void cleanAddressRegister(String agreement_nr, String farCustomerAddressId) {
        jdbcTemplate.update("delete from postal_register where agreement_nr=? and far_customer_address_identifier=?",
                agreement_nr, farCustomerAddressId);
    }

    private void verifyCustomerRegisteredMessageInDeadLetterQueue(String exceptionType) {
        verify(deadLetterConsumer, times(1)).onMessage(isA(ConsumerRecord.class));
        Headers kafkaMessageHeaders = deadLetterConsumer.getKafkaMessageHeaders();
        assertEquals(topicName, new String(kafkaMessageHeaders.headers(KafkaHeaders.DLT_ORIGINAL_TOPIC).iterator().next().value()));
        assertEquals(1,   ByteBuffer.wrap(kafkaMessageHeaders.headers(ApplicationConstants.DLT_RETRY_COUNT)
                .iterator().next().value()).getInt());
        assertEquals(exceptionType, new String(kafkaMessageHeaders
                .headers(ApplicationConstants.DLT_EXCEPTION_TYPE).iterator().next().value()));
        assertTrue(kafkaMessageHeaders.headers(KafkaHeaders.DLT_EXCEPTION_FQCN).iterator().hasNext());
        assertTrue(kafkaMessageHeaders.headers(KafkaHeaders.DLT_EXCEPTION_STACKTRACE).iterator().hasNext());
        assertTrue(kafkaMessageHeaders.headers(KafkaHeaders.DLT_EXCEPTION_MESSAGE).iterator().hasNext());
        assertTrue(kafkaMessageHeaders.headers(KafkaHeaders.DLT_ORIGINAL_PARTITION).iterator().hasNext());
        assertTrue(kafkaMessageHeaders.headers(KafkaHeaders.DLT_ORIGINAL_OFFSET).iterator().hasNext());
        assertTrue(kafkaMessageHeaders.headers(KafkaHeaders.DLT_ORIGINAL_TIMESTAMP).iterator().hasNext());
        assertTrue(kafkaMessageHeaders.headers(KafkaHeaders.DLT_ORIGINAL_TIMESTAMP_TYPE).iterator().hasNext());
    }

    private void createPostalAgreementFieldsCheck(PostalRegister PostalRegister, PostalRegisterId PostalRegisterId, PostalRegister expectedAgreementReg){
        assertThat(PostalRegisterId.getAgreementNr(), equalTo(expectedAgreementReg.getPostalRegisterId().getAgreementNr()));
        assertThat(PostalRegisterId.getFarCustomerAddressIdentifier(),
                equalTo(expectedAgreementReg.getPostalRegisterId().getFarCustomerAddressIdentifier()));
        assertThat(PostalRegister.getPostalTypeCode(),equalTo(expectedAgreementReg.getPostalTypeCode()));
        assertThat(PostalRegister.getDescription(),equalTo(expectedAgreementReg.getDescription()));
        assertThat(PostalRegister.getMobileNr(),equalTo(expectedAgreementReg.getMobileNr()));
        assertThat(PostalRegister.getDeliveryPostalCode(),equalTo(expectedAgreementReg.getDeliveryPostalCode()));
        assertThat(PostalRegister.getDeliveryCountryCode(),equalTo(expectedAgreementReg.getDeliveryCountryCode()));
        assertThat(PostalRegister.getCustomerNr(),equalTo(expectedAgreementReg.getCustomerNr()));
        assertThat(PostalRegister.getName(),equalTo(expectedAgreementReg.getName()));
        assertThat(PostalRegister.getDeliveryAddressLine1(),equalTo(expectedAgreementReg.getDeliveryAddressLine1()));
        assertThat(PostalRegister.getDeliveryAddressLine2(),equalTo(expectedAgreementReg.getDeliveryAddressLine2()));
        assertThat(PostalRegister.getDeliveryPostalArea(),equalTo(expectedAgreementReg.getDeliveryPostalArea()));
        assertThat(PostalRegister.getEmailAdr(),equalTo(expectedAgreementReg.getEmailAdr()));
        assertThat(PostalRegister.getDeliveryInstructions(),equalTo(expectedAgreementReg.getDeliveryInstructions()));
        assertThat(PostalRegister.getActiveStatus(),equalTo(expectedAgreementReg.getActiveStatus()));
        assertThat(PostalRegister.getStartDate(),equalTo(expectedAgreementReg.getStartDate()));
        assertThat(PostalRegister.getEndDate(),equalTo(expectedAgreementReg.getEndDate()));
        assertThat(PostalRegister.getWeekNr(), notNullValue());

    }


}

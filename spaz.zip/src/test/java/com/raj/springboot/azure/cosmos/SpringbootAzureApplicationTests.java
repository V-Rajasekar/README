package com.raj.springboot.azure.cosmos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAzureApplicationTests {

	@Test
	void contextLoads() {
	}

}

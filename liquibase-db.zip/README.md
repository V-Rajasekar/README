# local-db-db

> This repo is used for setting up Postgres DB on local, SIT, QA and Production environments

## Local setup
We have a shell script invoked by Gradle to take care of creating a Parcel Hub user (`ph_user`) and a database (local-db) on your local postgres server. The init script will assume a default native Postgres install using the `postgres` user as the administrator by default, but it also supports overriding the defaults by setting and exporting `PSQL_ARGS` in the terminal before running the commands.

### Alternative 1: Using a native Postgres install

Before running the below commands, make sure you have [installed Postgres][db-page] and that the PostgresSQL client `psql` is available on your environment's `PATH`. On Windows the path is usually something like `C:\Program Files\PostgresSQL\16\bin`. See [How to set environment variables on Windows](https://pureinfotech.com/create-custom-environment-variables-windows-10/)

[db-page]: https://postennorgeas.atlassian.net/wiki/spaces/PH/pages/451444926/Developer+Workspace+Setup

* Please make sure all database connections to local-db database are terminated 
* Set the local postgres password in the environment variable `PGPASSWORD`
* Run all the below commands in a terminal running a POSIX shell, like the one that comes with [GitBash](https://gitforwindows.org/). 

```
./gradlew task initDb

# To create tables in local-db database in mdm & logs schema

./gradlew task dev liquibaseUpdate
```

### Alternative 2: customising which database to use

You can easily override the user, host and port used by the init script by setting `PSQL_ARGS` before initialising the database. Here is how you could do this (example taken from the [NBM project](https://github.com/bring/ph-nbm-notification-processor-v1)): 
```
export DB_PORT=54347 
export DB_HOST=localhost
export PGPASSWORD=ph-nbm-notification-processor-v1
export PSQL_ARGS=" -U ph-nbm-notification-processor-v1 -h $DB_HOST -p $DB_PORT"
./gradlew task initDb

# Will use DB_PORT and DB_HOST, if supplied, to override defaults when running the liquibase migrations
./gradlew task dev liquibaseUpdate
```

#### On errors: how to add the `postgres` role if missing
> This section should no longer be required, as we do not explicitly use the 
> `postgres` user in the local setup.

<details>

If you get an error such as `psql: error: FATAL:  role "postgres" does not exist`, then you could try to run the below script:
```
(bash sell)$psql postgres
CREATE ROLE postgres WITH LOGIN PASSWORD 'postgres' ;
ALTER ROLE postgres CREATEDB SUPERUSER CREATEROLE REPLICATION BYPASSRLS;
CREATE DATABASE postgres WITH OWNER postgres;
```

</details>

## Recommended Folder structure

```
src/main/resources/database
│     
│
└───database-name
    │   changeLog.xml - includes files for all schema's changes logs  
    │
    └───schema1-name
    │      changeLog.xml - includes files for current schema's change logs
    │      create-constraints.xml - file containing changeSets for adding database objects
    │      create-sequence.xml
    │      create-table1.xml
    │      create-table2.xml
    │   
    │   
    └───schema2-name
    │      changeLog.xml - includes files for current schema's change logs
    │      create-constraints.xml - file containing changeSets for adding database objects
    │      create-sequence.xml
    │      create-table1.xml
    │      create-table2.xml
    │   
```

## Liquibase is used to manage database changes automation
> [Official Liquibase docs](https://docs.liquibase.com/)

- To add a table, create new file e.g. create-table-<table-name>.xml. Add this file to the corresponding schema folder
- Include this new file in schema folder's `changeLog.xml`
- Convention followed is `changeLog.xml` file to have consolidated changes for the schema
- When adding changeSet, use your github id as `author`
- Make sure in each changeSet to specify `context`. Possible values of context are: `dev`, `sit`, `qa` and `prod`
- Gradle task would connect to postgres database and applies the liquibase changes
- When changeSets applied in SIT, all the upper environment changes would be already considered. i.e. SIT would get changes for context sit, qa & prod but not dev
- Similarly when changeSets applies in QA, only the context qa & prod would be applied but not sit and dev
- Whenever you want to move the tables to further environments you need to update the context accordingly. i.e. when you create a table in SIT, you specify context as `sit`, to move this to QA, change context to `qa`   

### ChangeSet Example
<details>

```
<changeSet author="mkushe" context="prod" id="create-table-ph_event_process_status_type">
    <createTable schemaName="logs" tableName="ph_event_process_status_type">
      <column name="id" type="BIGINT">
        <constraints nullable="false" primaryKeyName="ph_event_process_status_type_pkey" primaryKey="true"/>
      </column>
      <column name="description" type="VARCHAR(255)"/>
      <column name="status_type_id" type="BIGINT"/>
    </createTable>
  </changeSet>
  <changeSet author="mkushe" context="prod" id="add-primarykey-ph_event_process_status_type_status_type_id_key">
    <addUniqueConstraint columnNames="status_type_id" constraintName="ph_event_process_status_type_status_type_id_key" schemaName="logs" tableName="ph_event_process_status_type"/>
  </changeSet>
```

</details>

## To generate liquibase scripts from existing database
    `./gradlew task qa liquibaseGenerateChangeLog`
    `./gradlew task transform` - for splitting single huge liquibase file into table specific files, this needs to be verified manually. Also environment corresponding `context` to be added in each changeset
    Before running this task, rename changeLog.xml to changelog_<schema-name>_original.xml. As this task will be creating changeLog.xml

## Apply liquibase changes in SIT
    This can be run from Github Action, in case if you need to run this manually run below command.
    `dbName` can be either of `ODS` or `MRP`
    `./gradlew task sit -PdbName=ODS liquibaseUpdate`     

## Apply liquibase changes in QA
    This can be run from Github Action, in case if you need to run this manually run below command.
`dbName` can be either of `ODS` or `MRP`
    `./gradlew task qa -PdbName=ODS liquibaseUpdate`     

## Apply liquibase changes in PROD
    This can be run from Github Action, in case if you need to run this manually run below command
`dbName` can be either of `ODS` or `MRP`    
`./gradlew task prod -PdbName=ODS liquibaseUpdate`     


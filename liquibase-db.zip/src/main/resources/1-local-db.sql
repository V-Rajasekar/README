CREATE SCHEMA home AUTHORIZATION local_user;

GRANT ALL PRIVILEGES ON SCHEMA home TO local_user;

GRANT CREATE ON SCHEMA public TO local_user;




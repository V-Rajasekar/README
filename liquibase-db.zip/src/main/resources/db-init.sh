#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

usage(){
  echo
  echo USAGE: ./$0
  psql_tips
}

psql_tips(){
  cat <<EOF

# Tips for handling postgres errors

You can set the environment variable PSQL_ARGS to customize how the script connects to your database
By default, it will use 'trust' authentication, bypassing password prompts, but if your local database
is not running on a socket, say using a Docker database where you need to connect using TCP, you can
override how it connects by setting that environment variable

export PSQL_ARGS="-U postgres -h localhost -p 5432"
./gradlew task initDb     # or just ./db-init.sh  , if invoking directly

You can also use 'read -s PGPASSWORD' to avoid being prompted for password.
(Alternatively, set the password in .pgpass - see https://www.postgresql.org/docs/current/libpq-pgpass.html)

EOF
}
``
handle_failure(){
  echo "The script failed for some reason with exit code $?"
  echo "Confer to the usage docs for how to customize database connectivity"
  usage
  exit 1
}


main(){
  # if we are sent any arguments, print the usage text
  if [[ $# != 0 ]]; then
    usage
    exit 0
  fi

  if [[ "$DEBUG" != "" ]]; then
    # will echo each shell statement if DEBUG is set
    set -x
  fi

  do_psql             --file "$SCRIPT_DIR/0-initial-db-creation.sql"
  do_psql -d local-db   --file "$SCRIPT_DIR/1-local-db.sql"
}

do_psql(){
    # allow overrides, with defaults
    local ARGS=${PSQL_ARGS:-""}
    printf "\npsql %s %s\n" "$ARGS" "$*"

    if [[ "$DEBUG" != "" ]]; then
      # make it easy to see which line failed
      ARGS=" -v ECHO=all $ARGS"
    fi

    # -X avoids reading in the users custom .psqlrc file, which could cause errors
    # ON_ERROR_STOP=on means the script fails on the first error. The init script should have no errors
    psql -X -v ON_ERROR_STOP=on  $ARGS "$@"

    local exit_status=$?
    if [[ ! $exit_status -eq 0 ]]; then
      local PSQL_CONN_ERR=2
      if [[ $exit_status -eq $PSQL_CONN_ERR ]]; then
        psql_tips
      fi
      exit $exit_status
    fi
}

main $@

-- This file sets up all the initial databases and roles
-- It needs to be run with a user/role that has permissions
-- to create databases (usally the `postgres` user)

DROP DATABASE IF EXISTS "local-db";
DROP USER IF EXISTS "local_user";

CREATE ROLE local_user WITH LOGIN PASSWORD 'postgres';
CREATE DATABASE "local-db";










